export function formatMinutes(mins: number): string {
  const hours = Math.floor(mins / 60);
  const remaining = mins % 60;
  if (hours === 0) return `${remaining}m`;
  return `${hours}h ${remaining}m`;
}

export function formatWeight(lbs: number): string {
  return `${lbs.toLocaleString()} lbs`;
}

export function calculateDetentionAccrued(dwellMinutes: number, freeTimeLimitMinutes: number, ratePerHour: number): number {
  if (dwellMinutes <= freeTimeLimitMinutes) return 0;
  const overtimeMinutes = dwellMinutes - freeTimeLimitMinutes;
  const overtimeHours = overtimeMinutes / 60;
  return Math.round(overtimeHours * ratePerHour);
}

export function getDetentionStatus(dwellMinutes: number, freeTimeLimitMinutes: number): {
  status: 'nominal' | 'warning' | 'detention';
  minutesLeft: number;
  label: string;
} {
  const minutesLeft = freeTimeLimitMinutes - dwellMinutes;
  if (minutesLeft <= 0) {
    return {
      status: 'detention',
      minutesLeft: 0,
      label: `Detention Active (+${Math.abs(minutesLeft)}m)`
    };
  }
  if (minutesLeft <= 30) {
    return {
      status: 'warning',
      minutesLeft,
      label: `${minutesLeft}m before fee`
    };
  }
  return {
    status: 'nominal',
    minutesLeft,
    label: `${formatMinutes(minutesLeft)} free time`
  };
}
