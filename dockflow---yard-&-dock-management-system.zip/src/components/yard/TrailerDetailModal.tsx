import React, { useState } from 'react';
import { X, Truck, Thermometer, ShieldCheck, Clock, ArrowRight, AlertTriangle, Zap, CheckCircle2 } from 'lucide-react';
import { Trailer, DockDoor, YardSpot } from '../../types/yard';
import { formatMinutes, calculateDetentionAccrued, getDetentionStatus } from '../../utils/helpers';
import { sounds } from '../../utils/audio';

interface TrailerDetailModalProps {
  trailer: Trailer | null;
  dockDoors: DockDoor[];
  yardSpots: YardSpot[];
  onClose: () => void;
  onDispatchMove: (trailerId: string, toLocation: string, reason: string) => void;
  onDepartTrailer: (trailerId: string) => void;
}

export const TrailerDetailModal: React.FC<TrailerDetailModalProps> = ({
  trailer,
  dockDoors,
  yardSpots,
  onClose,
  onDispatchMove,
  onDepartTrailer
}) => {
  const [selectedTargetLocation, setSelectedTargetLocation] = useState<string>('');
  const [moveReason, setMoveReason] = useState<string>('Operational Relocation');
  const [isDispatching, setIsDispatching] = useState<boolean>(false);

  if (!trailer) return null;

  const detentionInfo = getDetentionStatus(trailer.dwellMinutes, trailer.freeTimeLimitMinutes);
  const accruedDetentionFee = calculateDetentionAccrued(
    trailer.dwellMinutes,
    trailer.freeTimeLimitMinutes,
    trailer.detentionRatePerHour
  );

  const availableDocks = dockDoors.filter(d => d.status === 'available');
  const emptySpots = yardSpots.filter(s => !s.occupiedTrailerId);

  const handleExecuteMove = () => {
    if (!selectedTargetLocation) return;
    onDispatchMove(trailer.id, selectedTargetLocation, moveReason);
    sounds.playRadioChirp();
    setIsDispatching(false);
    onClose();
  };

  const handleDepart = () => {
    onDepartTrailer(trailer.id);
    sounds.playGateChime();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-800 border border-slate-700 rounded text-cyan-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white font-mono tracking-tight">{trailer.id}</h2>
                <span className="text-xs text-slate-400">·</span>
                <span className="text-sm font-semibold text-slate-200">{trailer.carrier}</span>
                <span className="text-xs text-slate-400">·</span>
                <span className="text-xs font-mono uppercase text-slate-400">{trailer.trailerType.replace('_', ' ')}</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Current Location: <span className="font-mono text-cyan-400 font-semibold">{trailer.locationId}</span>
                {' · '}
                BOL: <span className="font-mono text-slate-300">{trailer.bolNumber}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Detention & Dwell Alert Banner */}
          <div className={`p-4 rounded-md border ${
            detentionInfo.status === 'detention'
              ? 'bg-rose-950/40 border-rose-800/80 text-rose-200'
              : detentionInfo.status === 'warning'
              ? 'bg-amber-950/40 border-amber-800/80 text-amber-200'
              : 'bg-slate-800/50 border-slate-700/60 text-slate-300'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                {detentionInfo.status === 'detention' ? (
                  <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                ) : detentionInfo.status === 'warning' ? (
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                ) : (
                  <Clock className="w-5 h-5 text-cyan-400 shrink-0" />
                )}
                <div>
                  <div className="text-sm font-semibold">
                    {detentionInfo.status === 'detention' ? 'Carrier Detention Penalty Incurring' : 'Dwell Time & Detention Status'}
                  </div>
                  <div className="text-xs mt-0.5 opacity-90">
                    Total yard dwell: <span className="font-mono font-bold tabular-nums">{formatMinutes(trailer.dwellMinutes)}</span>
                    {' · '}
                    Free limit: <span className="font-mono font-bold tabular-nums">{formatMinutes(trailer.freeTimeLimitMinutes)}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono text-xs uppercase tracking-wide opacity-75">Detention Liability</div>
                <div className={`text-base font-bold font-mono tabular-nums ${accruedDetentionFee > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                  ${accruedDetentionFee}
                  <span className="text-xs font-normal opacity-75 ml-1">(@${trailer.detentionRatePerHour}/hr)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Reefer Telematics Section (if applicable) */}
          {trailer.reefer && (
            <div className="p-4 bg-slate-900 border border-teal-900/60 rounded-md">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2 text-teal-400">
                  <Thermometer className="w-4 h-4" />
                  <span className="text-sm font-semibold tracking-tight">Cold-Chain Reefer Telematics</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span>Status: <span className="font-semibold text-emerald-400 uppercase">{trailer.reefer.status}</span></span>
                  <span>·</span>
                  <span>Plugged: {trailer.reefer.pluggedIn ? (
                    <span className="text-emerald-400 font-semibold inline-flex items-center gap-0.5"><Zap className="w-3 h-3" /> Shore Power</span>
                  ) : (
                    <span className="text-amber-400 font-semibold">Diesel Run</span>
                  )}</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-3 text-center">
                <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Current Cargo Temp</span>
                  <span className={`text-xl font-bold font-mono tabular-nums ${
                    Math.abs(trailer.reefer.currentTempF - trailer.reefer.setPointF) > 2 ? 'text-rose-400' : 'text-teal-300'
                  }`}>
                    {trailer.reefer.currentTempF > 0 ? `+${trailer.reefer.currentTempF}` : trailer.reefer.currentTempF}°F
                  </span>
                </div>
                <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Set Point Target</span>
                  <span className="text-xl font-bold font-mono text-slate-300 tabular-nums">
                    {trailer.reefer.setPointF > 0 ? `+${trailer.reefer.setPointF}` : trailer.reefer.setPointF}°F
                  </span>
                </div>
                <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Diesel Fuel Reserve</span>
                  <span className={`text-xl font-bold font-mono tabular-nums ${
                    trailer.reefer.fuelLevelPercent < 25 ? 'text-rose-400' : 'text-slate-300'
                  }`}>
                    {trailer.reefer.fuelLevelPercent}%
                  </span>
                </div>
              </div>
              {trailer.reefer.alarmCode && (
                <div className="mt-3 p-2 bg-amber-950/40 border border-amber-800/80 rounded text-xs text-amber-200 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{trailer.reefer.alarmCode} - Hostler fuel run recommended immediately.</span>
                </div>
              )}
            </div>
          )}

          {/* Cargo Manifest & Inspection */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-950/60 rounded border border-slate-800 space-y-2">
              <span className="text-slate-400 font-semibold block uppercase tracking-wider text-[11px]">Load Details</span>
              <div>
                <span className="text-slate-400">Cargo:</span>{' '}
                <span className="font-semibold text-slate-200">{trailer.cargoDescription}</span>
              </div>
              <div>
                <span className="text-slate-400">Pallets:</span>{' '}
                <span className="font-mono font-semibold text-slate-200">{trailer.palletsCount} standard pallets</span>
              </div>
              <div>
                <span className="text-slate-400">Gross Cargo Weight:</span>{' '}
                <span className="font-mono font-semibold text-slate-200">{trailer.weightLbs.toLocaleString()} lbs</span>
              </div>
            </div>

            <div className="p-3 bg-slate-950/60 rounded border border-slate-800 space-y-2">
              <span className="text-slate-400 font-semibold block uppercase tracking-wider text-[11px]">Security & Carrier Data</span>
              <div>
                <span className="text-slate-400">Seal Number:</span>{' '}
                <span className="font-mono font-semibold text-cyan-400">{trailer.sealNumber}</span>{' '}
                {trailer.isSealed ? (
                  <span className="text-emerald-400 inline-flex items-center gap-0.5 text-[11px]">
                    <ShieldCheck className="w-3.5 h-3.5 inline" /> Verified Intact
                  </span>
                ) : (
                  <span className="text-slate-400 text-[11px]">(Unsealed / Empty)</span>
                )}
              </div>
              <div>
                <span className="text-slate-400">Driver:</span>{' '}
                <span className="font-semibold text-slate-200">{trailer.driverName}</span>{' '}
                <span className="text-slate-400">({trailer.driverPhone})</span>
              </div>
              <div>
                <span className="text-slate-400">Tractor Plate:</span>{' '}
                <span className="font-mono font-semibold text-slate-200">{trailer.tractorPlate}</span>
              </div>
            </div>
          </div>

          {/* Move Dispatcher Drawer */}
          {isDispatching ? (
            <div className="p-4 bg-slate-800/80 border border-cyan-800/80 rounded-md space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white flex items-center gap-2">
                  <ArrowRight className="w-4 h-4 text-cyan-400" />
                  Dispatch Hostler Move Task
                </span>
                <button
                  onClick={() => setIsDispatching(false)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">Target Destination</label>
                  <select
                    value={selectedTargetLocation}
                    onChange={(e) => setSelectedTargetLocation(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="">Select Destination...</option>
                    <optgroup label="Available Dock Doors">
                      {availableDocks.map(d => (
                        <option key={d.id} value={d.id}>
                          {d.id} - {d.name} ({d.type})
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="Open Yard Staging Spots">
                      {emptySpots.slice(0, 10).map(s => (
                        <option key={s.id} value={s.id}>
                          Spot {s.id} ({s.zone})
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Reason / Priority</label>
                  <select
                    value={moveReason}
                    onChange={(e) => setMoveReason(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-200 focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="Prevent Carrier Detention Penalty">Prevent Carrier Detention Penalty</option>
                    <option value="Feed Dock Loading/Unloading Line">Feed Dock Loading/Unloading Line</option>
                    <option value="Stage for Outbound Departure">Stage for Outbound Departure</option>
                    <option value="Reefer Shore Power Plug-in">Reefer Shore Power Plug-in</option>
                    <option value="Empties Relocation">Empties Relocation</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setIsDispatching(false)}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={handleExecuteMove}
                  disabled={!selectedTargetLocation}
                  className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 disabled:cursor-not-allowed rounded transition-colors shadow-sm"
                >
                  Transmit Move Order to Hostlers
                </button>
              </div>
            </div>
          ) : null}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-900/90">
          <div className="text-xs text-slate-400">
            Check-in: <span className="font-mono">{new Date(trailer.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>

          <div className="flex items-center gap-3">
            {!isDispatching && (
              <button
                onClick={() => setIsDispatching(true)}
                className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
              >
                Create Hostler Move
              </button>
            )}

            {trailer.status === 'outbound_ready' && (
              <button
                onClick={handleDepart}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 rounded transition-colors"
              >
                Clear Gate Departure
              </button>
            )}

            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
