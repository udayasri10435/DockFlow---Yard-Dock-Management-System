import React, { useState } from 'react';
import { 
  Building2, 
  Truck, 
  Thermometer, 
  Clock, 
  Search, 
  Filter, 
  AlertTriangle, 
  Zap, 
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  Warehouse
} from 'lucide-react';
import { Trailer, DockDoor, YardSpot, SpotZone } from '../../types/yard';
import { formatMinutes, calculateDetentionAccrued, getDetentionStatus } from '../../utils/helpers';

interface YardMapViewProps {
  trailers: Trailer[];
  dockDoors: DockDoor[];
  yardSpots: YardSpot[];
  onSelectTrailer: (trailer: Trailer) => void;
  onSelectDock: (dock: DockDoor) => void;
  onNavigateTab: (tab: 'dock_schedule' | 'gate_kiosk' | 'detention_radar') => void;
}

export const YardMapView: React.FC<YardMapViewProps> = ({
  trailers,
  dockDoors,
  yardSpots,
  onSelectTrailer,
  onSelectDock,
  onNavigateTab
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'docks' | 'zone_a' | 'zone_b' | 'reefer' | 'empties' | 'detention'>('all');

  // Filter trailers
  const filteredTrailers = trailers.filter(t => {
    const matchesSearch = 
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.carrier.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.bolNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.locationId.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (selectedFilter === 'all') return true;
    if (selectedFilter === 'docks') return t.locationType === 'dock_door';
    if (selectedFilter === 'zone_a') return t.locationId.startsWith('A-');
    if (selectedFilter === 'zone_b') return t.locationId.startsWith('B-');
    if (selectedFilter === 'reefer') return t.trailerType === 'reefer_53' || t.locationId.startsWith('R-');
    if (selectedFilter === 'empties') return t.status === 'empty_staged' || t.locationId.startsWith('E-');
    if (selectedFilter === 'detention') return (t.freeTimeLimitMinutes - t.dwellMinutes) <= 30;

    return true;
  });

  const trailersByLocation = new Map<string, Trailer>();
  trailers.forEach(t => trailersByLocation.set(t.locationId, t));

  // Quick stats
  const activeDockCount = dockDoors.filter(d => d.status === 'docked_active' || d.status === 'staged').length;
  const criticalDetentionCount = trailers.filter(t => t.dwellMinutes > t.freeTimeLimitMinutes).length;
  const warningDetentionCount = trailers.filter(t => {
    const left = t.freeTimeLimitMinutes - t.dwellMinutes;
    return left > 0 && left <= 30;
  }).length;
  const reeferCount = trailers.filter(t => t.trailerType === 'reefer_53').length;

  return (
    <div className="space-y-6">
      {/* Top Overview KPI Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Total Trailers in Yard</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">{trailers.length}</span>
            <span className="text-xs text-slate-500">trailers</span>
          </div>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Active Dock Bays</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">
              {activeDockCount}
              <span className="text-slate-500 text-base font-normal">/{dockDoors.length}</span>
            </span>
            <span className="text-xs text-emerald-400 font-mono">
              {Math.round((activeDockCount / dockDoors.length) * 100)}% Util
            </span>
          </div>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg cursor-pointer hover:border-amber-600 transition-colors"
          onClick={() => onNavigateTab('detention_radar')}
        >
          <span className="text-xs text-slate-400 block flex items-center justify-between">
            <span>Detention Risk</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
              {criticalDetentionCount + warningDetentionCount}
            </span>
            <span className="text-xs text-rose-400 font-mono">
              {criticalDetentionCount} Overdue
            </span>
          </div>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Reefer Cold-Chain</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-teal-400 tabular-nums">{reeferCount}</span>
            <span className="text-xs text-teal-300 flex items-center gap-0.5">
              <Zap className="w-3 h-3 text-teal-400" /> 100% Monitored
            </span>
          </div>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Hostlers On Yard</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">2</span>
            <span className="text-xs text-emerald-400 font-mono">Active Cycle</span>
          </div>
        </div>
      </div>

      {/* Control & Search Ribbon */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search Trailer #, Carrier, BOL, Spot (e.g. TLR-8419, Swift, A-01)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-xs bg-slate-900 border border-slate-700/80 rounded-md text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
          />
        </div>

        {/* Interactive Filter Tabs (Segmented Buttons) */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setSelectedFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              selectedFilter === 'all'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Yard ({trailers.length})
          </button>
          <button
            onClick={() => setSelectedFilter('docks')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              selectedFilter === 'docks'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Dock Doors (16)
          </button>
          <button
            onClick={() => setSelectedFilter('zone_a')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              selectedFilter === 'zone_a'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Zone A Inbound
          </button>
          <button
            onClick={() => setSelectedFilter('zone_b')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              selectedFilter === 'zone_b'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Zone B Outbound
          </button>
          <button
            onClick={() => setSelectedFilter('reefer')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              selectedFilter === 'reefer'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Reefer Row R
          </button>
          <button
            onClick={() => setSelectedFilter('empties')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              selectedFilter === 'empties'
                ? 'bg-zinc-500/20 text-zinc-300 border border-zinc-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Empties
          </button>
          <button
            onClick={() => setSelectedFilter('detention')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              selectedFilter === 'detention'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-semibold'
                : 'text-amber-400 hover:text-amber-300'
            }`}
          >
            At Risk / Overdue ({criticalDetentionCount + warningDetentionCount})
          </button>
        </div>
      </div>

      {/* Main Yard Schematic Canvas */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 space-y-8">
        
        {/* Section 1: Warehouse Loading Dock Wall */}
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div className="flex items-center gap-2">
              <Warehouse className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Distribution Center Dock Face (Doors D-01 to D-16)
              </h3>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span> Active Transfer
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400"></span> Staged
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-slate-600"></span> Available Bay
              </span>
              <button
                onClick={() => onNavigateTab('dock_schedule')}
                className="text-cyan-400 hover:underline inline-flex items-center gap-0.5 ml-2"
              >
                Open Dock Master <ArrowUpRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* 16 Dock Bays Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
            {dockDoors.map((door) => {
              const trailer = door.currentTrailerId ? trailersByLocation.get(door.id) : undefined;
              const isDetention = trailer && trailer.dwellMinutes > trailer.freeTimeLimitMinutes;
              const isWarning = trailer && !isDetention && (trailer.freeTimeLimitMinutes - trailer.dwellMinutes) <= 30;

              return (
                <div
                  key={door.id}
                  onClick={() => {
                    if (trailer) onSelectTrailer(trailer);
                    else onSelectDock(door);
                  }}
                  className={`p-2.5 rounded border transition-all cursor-pointer text-left relative flex flex-col justify-between min-h-[110px] ${
                    isDetention
                      ? 'bg-rose-950/30 border-rose-600/80 hover:border-rose-400'
                      : isWarning
                      ? 'bg-amber-950/30 border-amber-600/80 hover:border-amber-400'
                      : door.status === 'docked_active'
                      ? 'bg-slate-900/90 border-slate-700 hover:border-cyan-400'
                      : door.status === 'staged'
                      ? 'bg-cyan-950/20 border-cyan-800/80 hover:border-cyan-400'
                      : door.status === 'maintenance'
                      ? 'bg-slate-900/40 border-slate-800 opacity-60'
                      : 'bg-slate-900/40 border-dashed border-slate-800 hover:border-slate-600'
                  }`}
                >
                  {/* Door Tag & Type */}
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-white">{door.id}</span>
                    <span className={`text-[10px] font-mono uppercase ${
                      door.type === 'cold_storage' ? 'text-teal-400' : door.type === 'cross_dock' ? 'text-amber-400' : 'text-slate-500'
                    }`}>
                      {door.type === 'cold_storage' ? 'Cold' : door.type === 'cross_dock' ? 'X-Dock' : 'Dry'}
                    </span>
                  </div>

                  {/* Occupant / Progress */}
                  {door.status === 'maintenance' ? (
                    <div className="my-auto text-[11px] text-amber-500 font-medium">Out of Service</div>
                  ) : trailer ? (
                    <div className="space-y-1 my-1">
                      <div className="font-mono text-xs font-bold text-cyan-300 truncate">{trailer.id}</div>
                      <div className="text-[11px] text-slate-300 truncate">{trailer.carrier}</div>

                      {/* Operation status or progress */}
                      {door.status === 'docked_active' && (
                        <div className="space-y-0.5">
                          <div className="flex items-center justify-between text-[10px] text-slate-400">
                            <span className="capitalize">{door.operation}</span>
                            <span className="font-mono tabular-nums">{door.progressPercent}%</span>
                          </div>
                          <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                            <div
                              className="bg-emerald-400 h-full transition-all"
                              style={{ width: `${door.progressPercent}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="my-auto text-center py-2">
                      <span className="text-[11px] text-slate-500 font-mono">Available</span>
                    </div>
                  )}

                  {/* Dwell / ETA footer */}
                  <div className="pt-1 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                    {trailer ? (
                      <>
                        <span className={`font-mono tabular-nums ${isDetention ? 'text-rose-400 font-bold' : isWarning ? 'text-amber-400 font-bold' : 'text-slate-400'}`}>
                          {formatMinutes(trailer.dwellMinutes)} dwell
                        </span>
                        {isDetention && <span className="text-rose-400 font-bold">PENALTY</span>}
                      </>
                    ) : (
                      <span className="text-slate-600 text-[10px]">Ready to Spot</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 2: Concrete Apron & Hostler Roadway */}
        <div className="relative py-3 px-4 bg-slate-900/60 border border-slate-800 rounded flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="px-2 py-1 bg-amber-500/10 border border-amber-500/30 rounded text-amber-300 text-xs font-mono font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
              YARD ROADWAY APRON
            </div>
            <span className="text-xs text-slate-400 hidden md:inline">
              Hostlers Active: <span className="text-slate-200 font-medium">Jockey-01 (Mac)</span> spotted TLR-1120 · <span className="text-slate-200 font-medium">Jockey-02 (Sam)</span> on fuel run
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('gate_kiosk')}
              className="text-xs px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 transition-colors flex items-center gap-1"
            >
              Gate Inbound / Outbound View <ArrowUpRight className="w-3.5 h-3.5 text-cyan-400" />
            </button>
          </div>
        </div>

        {/* Section 3: Parking Stalls Grid by Zones */}
        <div className="space-y-6">
          
          {/* Zone A: Inbound Staging Stalls */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-cyan-400">ZONE A</span>
                <span className="text-xs text-slate-300 font-medium">Inbound Drop Staging (A-01 to A-10)</span>
              </div>
              <span className="text-xs text-slate-500">Awaiting dock door spot</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
              {yardSpots.filter(s => s.zone === 'Zone A (Inbound)').map(spot => {
                const trailer = spot.occupiedTrailerId ? trailersByLocation.get(spot.id) : undefined;
                const isDetention = trailer && trailer.dwellMinutes > trailer.freeTimeLimitMinutes;
                const isWarning = trailer && !isDetention && (trailer.freeTimeLimitMinutes - trailer.dwellMinutes) <= 30;

                return (
                  <div
                    key={spot.id}
                    onClick={() => trailer && onSelectTrailer(trailer)}
                    className={`p-2 rounded border text-left flex flex-col justify-between min-h-[92px] transition-all ${
                      trailer ? 'cursor-pointer hover:border-cyan-400' : 'cursor-default'
                    } ${
                      isDetention
                        ? 'bg-rose-950/30 border-rose-600/80'
                        : isWarning
                        ? 'bg-amber-950/30 border-amber-600/80'
                        : trailer
                        ? 'bg-slate-900 border-slate-700'
                        : 'bg-slate-950/40 border-dashed border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[11px] font-bold text-slate-400">{spot.id}</span>
                      {isDetention && <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>}
                    </div>

                    {trailer ? (
                      <div className="my-1">
                        <div className="font-mono text-xs font-bold text-white truncate">{trailer.id}</div>
                        <div className="text-[10px] text-slate-300 truncate">{trailer.carrier}</div>
                      </div>
                    ) : (
                      <div className="my-auto text-center">
                        <span className="text-[10px] text-slate-600 font-mono">Empty</span>
                      </div>
                    )}

                    <div className="text-[10px] font-mono text-slate-400 border-t border-slate-800/60 pt-0.5">
                      {trailer ? (
                        <span className={`tabular-nums ${isDetention ? 'text-rose-400 font-bold' : isWarning ? 'text-amber-400 font-bold' : 'text-slate-400'}`}>
                          {formatMinutes(trailer.dwellMinutes)}
                        </span>
                      ) : '—'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Zone B: Outbound Staging Stalls */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-blue-400">ZONE B</span>
                <span className="text-xs text-slate-300 font-medium">Outbound Staged (B-01 to B-10)</span>
              </div>
              <span className="text-xs text-slate-500">Loaded & Sealed · Awaiting pickup</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
              {yardSpots.filter(s => s.zone === 'Zone B (Outbound)').map(spot => {
                const trailer = spot.occupiedTrailerId ? trailersByLocation.get(spot.id) : undefined;

                return (
                  <div
                    key={spot.id}
                    onClick={() => trailer && onSelectTrailer(trailer)}
                    className={`p-2 rounded border text-left flex flex-col justify-between min-h-[92px] transition-all ${
                      trailer ? 'cursor-pointer hover:border-cyan-400 bg-slate-900 border-slate-700' : 'bg-slate-950/40 border-dashed border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[11px] font-bold text-slate-400">{spot.id}</span>
                      {trailer && <ShieldCheck className="w-3 h-3 text-emerald-400" />}
                    </div>

                    {trailer ? (
                      <div className="my-1">
                        <div className="font-mono text-xs font-bold text-white truncate">{trailer.id}</div>
                        <div className="text-[10px] text-slate-300 truncate">{trailer.carrier}</div>
                      </div>
                    ) : (
                      <div className="my-auto text-center">
                        <span className="text-[10px] text-slate-600 font-mono">Empty</span>
                      </div>
                    )}

                    <div className="text-[10px] font-mono text-slate-400 border-t border-slate-800/60 pt-0.5">
                      {trailer ? (
                        <span className="text-emerald-400">Ready Pick</span>
                      ) : '—'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Lower Two Columns: Reefer Row R and Empties E */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Reefer Row R */}
            <div className="p-4 bg-teal-950/10 border border-teal-900/40 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Thermometer className="w-4 h-4 text-teal-400" />
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    Reefer Row R (Cold-Chain Shore Plugs R-01 to R-06)
                  </h4>
                </div>
                <span className="text-[11px] text-teal-400 flex items-center gap-1 font-mono">
                  <Zap className="w-3 h-3" /> Shore Grid Live
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {yardSpots.filter(s => s.zone === 'Reefer Row R').map(spot => {
                  const trailer = spot.occupiedTrailerId ? trailersByLocation.get(spot.id) : undefined;
                  const reefer = trailer?.reefer;

                  return (
                    <div
                      key={spot.id}
                      onClick={() => trailer && onSelectTrailer(trailer)}
                      className={`p-2.5 rounded border text-left flex flex-col justify-between min-h-[105px] transition-all ${
                        trailer ? 'cursor-pointer hover:border-teal-400 bg-slate-900 border-slate-700' : 'bg-slate-950/40 border-dashed border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-teal-300">{spot.id}</span>
                        {reefer && (
                          <span className={`text-[10px] font-mono font-bold ${
                            reefer.fuelLevelPercent < 25 ? 'text-rose-400 animate-pulse' : 'text-slate-400'
                          }`}>
                            Fuel: {reefer.fuelLevelPercent}%
                          </span>
                        )}
                      </div>

                      {trailer && reefer ? (
                        <div className="space-y-1 my-1">
                          <div className="font-mono text-xs font-bold text-white truncate">{trailer.id}</div>
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] text-slate-300 truncate">{trailer.carrier}</span>
                            <span className="text-xs font-mono font-bold text-teal-300 tabular-nums">
                              {reefer.currentTempF > 0 ? `+${reefer.currentTempF}` : reefer.currentTempF}°F
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="my-auto text-center">
                          <span className="text-[11px] text-slate-600 font-mono">Plug Available</span>
                        </div>
                      )}

                      <div className="text-[10px] font-mono text-slate-400 border-t border-slate-800/80 pt-1 flex items-center justify-between">
                        {trailer ? (
                          <>
                            <span className="text-slate-400">{formatMinutes(trailer.dwellMinutes)} dwell</span>
                            <span className="text-emerald-400 font-semibold">PLUGGED</span>
                          </>
                        ) : 'Ready'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Empties Zone E */}
            <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-slate-400" />
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    Empty Equipment Staging (E-01 to E-06)
                  </h4>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">Reload Buffer Pool</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {yardSpots.filter(s => s.zone === 'Empties E').map(spot => {
                  const trailer = spot.occupiedTrailerId ? trailersByLocation.get(spot.id) : undefined;

                  return (
                    <div
                      key={spot.id}
                      onClick={() => trailer && onSelectTrailer(trailer)}
                      className={`p-2.5 rounded border text-left flex flex-col justify-between min-h-[105px] transition-all ${
                        trailer ? 'cursor-pointer hover:border-slate-400 bg-slate-900 border-slate-700' : 'bg-slate-950/40 border-dashed border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-slate-400">{spot.id}</span>
                        {trailer && <span className="text-[10px] text-zinc-400 font-mono">SWPT & INSP</span>}
                      </div>

                      {trailer ? (
                        <div className="my-1">
                          <div className="font-mono text-xs font-bold text-slate-200 truncate">{trailer.id}</div>
                          <div className="text-[10px] text-slate-400 truncate">{trailer.carrier}</div>
                        </div>
                      ) : (
                        <div className="my-auto text-center">
                          <span className="text-[11px] text-slate-600 font-mono">Empty Stall</span>
                        </div>
                      )}

                      <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/80 pt-1">
                        {trailer ? 'Available for Reload' : 'Open'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
