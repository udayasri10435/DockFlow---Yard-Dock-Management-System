import React, { useState } from 'react';
import { 
  Warehouse, 
  Calendar, 
  Clock, 
  Plus, 
  CheckCircle2, 
  Play, 
  AlertTriangle, 
  Users, 
  ArrowRight,
  Filter,
  Check
} from 'lucide-react';
import { DockDoor, Trailer, Appointment } from '../../types/yard';
import { formatMinutes } from '../../utils/helpers';
import { sounds } from '../../utils/audio';

interface DockScheduleViewProps {
  dockDoors: DockDoor[];
  trailers: Trailer[];
  appointments: Appointment[];
  onUpdateDock: (updatedDoor: DockDoor) => void;
  onScheduleAppointment: (newAppt: Appointment) => void;
  onRequestHostlerPull: (dockId: string, trailerId: string) => void;
}

export const DockScheduleView: React.FC<DockScheduleViewProps> = ({
  dockDoors,
  trailers,
  appointments,
  onUpdateDock,
  onScheduleAppointment,
  onRequestHostlerPull
}) => {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'dry' | 'cold_storage' | 'cross_dock'>('all');
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);

  // New appointment form state
  const [carrier, setCarrier] = useState('Knight-Swift');
  const [apptType, setApptType] = useState<'inbound_unload' | 'outbound_load'>('inbound_unload');
  const [scheduledTime, setScheduledTime] = useState('02:00 PM');
  const [selectedDockId, setSelectedDockId] = useState('D-03');
  const [cargoType, setCargoType] = useState('Beverage Pallets (Bottled Water)');
  const [pallets, setPallets] = useState(24);
  const [poNumber, setPoNumber] = useState('PO-772184');

  const filteredDoors = dockDoors.filter(door => {
    if (selectedFilter === 'all') return true;
    return door.type === selectedFilter;
  });

  const trailersByDock = new Map<string, Trailer>();
  trailers.forEach(t => {
    if (t.locationType === 'dock_door') {
      trailersByDock.set(t.locationId, t);
    }
  });

  const handleStartOperation = (door: DockDoor) => {
    onUpdateDock({
      ...door,
      status: 'docked_active',
      operation: door.operation === 'idle' ? 'unloading' : door.operation,
      progressPercent: Math.max(15, door.progressPercent)
    });
    sounds.playSuccessTone();
  };

  const handleAdvanceProgress = (door: DockDoor) => {
    const nextProgress = Math.min(100, door.progressPercent + 25);
    onUpdateDock({
      ...door,
      progressPercent: nextProgress,
      estimatedRemainingMinutes: Math.max(0, Math.round(door.estimatedRemainingMinutes * 0.6))
    });
    if (nextProgress === 100) {
      sounds.playSuccessTone();
    }
  };

  const handleCompleteAndCallPull = (door: DockDoor) => {
    if (!door.currentTrailerId) return;
    onRequestHostlerPull(door.id, door.currentTrailerId);
    sounds.playRadioChirp();
    onUpdateDock({
      ...door,
      status: 'available',
      currentTrailerId: undefined,
      operation: 'idle',
      progressPercent: 0,
      estimatedRemainingMinutes: 0,
      assignedCrew: 'Unassigned'
    });
  };

  const handleCreateAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const newAppt: Appointment = {
      id: `APT-${Math.floor(1020 + Math.random() * 800)}`,
      carrier,
      type: apptType,
      scheduledTime,
      dockDoorId: selectedDockId,
      cargoType,
      pallets,
      poNumber,
      status: 'scheduled'
    };
    onScheduleAppointment(newAppt);
    sounds.playSuccessTone();
    setIsScheduleModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Appointment CTA */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-lg">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Warehouse className="w-5 h-5 text-cyan-400" />
            <span>Dock Door Master & Live Unload/Load Board</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Optimize turn times, prevent dock starvation, and coordinate warehouse lumper crews.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Filter tabs */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedFilter === 'all' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Doors (16)
            </button>
            <button
              onClick={() => setSelectedFilter('dry')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedFilter === 'dry' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Dry Bays (10)
            </button>
            <button
              onClick={() => setSelectedFilter('cold_storage')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedFilter === 'cold_storage' ? 'bg-slate-800 text-teal-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Cold Storage (4)
            </button>
            <button
              onClick={() => setSelectedFilter('cross_dock')}
              className={`px-2.5 py-1 rounded transition-colors ${
                selectedFilter === 'cross_dock' ? 'bg-slate-800 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Cross-Dock (2)
            </button>
          </div>

          <button
            onClick={() => setIsScheduleModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors shadow-sm whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule Appointment</span>
          </button>
        </div>
      </div>

      {/* Dock Doors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredDoors.map((door) => {
          const trailer = door.currentTrailerId ? trailersByDock.get(door.id) : undefined;

          return (
            <div
              key={door.id}
              className={`p-4 bg-slate-900 border rounded-lg transition-all flex flex-col justify-between ${
                door.status === 'docked_active'
                  ? 'border-slate-700 shadow-md'
                  : door.status === 'staged'
                  ? 'border-cyan-800/80 bg-cyan-950/10'
                  : door.status === 'maintenance'
                  ? 'border-slate-800 opacity-60'
                  : 'border-dashed border-slate-800'
              }`}
            >
              {/* Card Header */}
              <div>
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-bold text-white">{door.id}</span>
                    <span className="text-xs text-slate-400 font-medium">{door.name}</span>
                  </div>
                  <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${
                    door.type === 'cold_storage'
                      ? 'bg-teal-950/40 text-teal-300 border-teal-800/60'
                      : door.type === 'cross_dock'
                      ? 'bg-amber-950/40 text-amber-300 border-amber-800/60'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    {door.type === 'cold_storage' ? 'Cold Bay' : door.type === 'cross_dock' ? 'X-Dock' : 'Dry Van'}
                  </span>
                </div>

                {/* Content */}
                {door.status === 'maintenance' ? (
                  <div className="py-4 text-center space-y-1">
                    <AlertTriangle className="w-5 h-5 text-amber-400 mx-auto" />
                    <span className="text-xs text-amber-300 font-medium block">Bay Under Maintenance</span>
                    <span className="text-[11px] text-slate-500 block">{door.assignedCrew}</span>
                  </div>
                ) : trailer ? (
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-mono text-xs font-bold text-cyan-300 block">{trailer.id}</span>
                        <span className="text-xs font-medium text-slate-200">{trailer.carrier}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-mono uppercase text-slate-400 block">Operation</span>
                        <span className="text-xs font-semibold text-emerald-400 uppercase capitalize">{door.operation}</span>
                      </div>
                    </div>

                    <div className="p-2.5 bg-slate-950 rounded border border-slate-800 text-[11px] text-slate-300 space-y-1">
                      <div className="truncate">{trailer.cargoDescription}</div>
                      <div className="flex items-center justify-between text-slate-400 font-mono">
                        <span>{trailer.palletsCount} Pallets</span>
                        <span>{trailer.weightLbs.toLocaleString()} lbs</span>
                      </div>
                    </div>

                    {/* Progress Bar & ETA */}
                    {door.status === 'docked_active' && (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs text-slate-400">
                          <span>Unload Progress</span>
                          <span className="font-mono font-bold text-white tabular-nums">{door.progressPercent}%</span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all ${
                              door.progressPercent >= 100 ? 'bg-emerald-400' : 'bg-cyan-400'
                            }`}
                            style={{ width: `${door.progressPercent}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                          <span>ETA: {door.estimatedRemainingMinutes}m left</span>
                          <span>Crew: {door.assignedCrew.split(' ')[0]}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="py-6 text-center space-y-2">
                    <div className="w-8 h-8 rounded-full bg-slate-800/80 border border-slate-700/80 flex items-center justify-center mx-auto text-slate-500 font-mono text-xs">
                      {door.id.replace('D-', '')}
                    </div>
                    <div>
                      <span className="text-xs font-medium text-slate-400 block">Bay Available</span>
                      <span className="text-[11px] text-slate-600 block">Ready for next scheduled inbound</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-800/80 mt-4 flex items-center gap-2">
                {door.status === 'staged' && (
                  <button
                    onClick={() => handleStartOperation(door)}
                    className="w-full py-1.5 px-3 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Begin Unload</span>
                  </button>
                )}

                {door.status === 'docked_active' && (
                  <>
                    <button
                      onClick={() => handleAdvanceProgress(door)}
                      className="flex-1 py-1.5 px-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                    >
                      +25% Done
                    </button>
                    <button
                      onClick={() => handleCompleteAndCallPull(door)}
                      className="flex-1 py-1.5 px-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 rounded transition-colors"
                    >
                      Call Hostler Pull
                    </button>
                  </>
                )}

                {door.status === 'available' && (
                  <button
                    onClick={() => {
                      setSelectedDockId(door.id);
                      setIsScheduleModalOpen(true);
                    }}
                    className="w-full py-1.5 px-3 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                  >
                    Assign Appointment
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Appointment Schedule Timeline Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Distribution Center Appointment Schedule
            </h3>
          </div>
          <span className="text-xs text-slate-400">Strict SLA Carrier Slots</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono">
                <th className="py-2.5 px-3">Appointment ID</th>
                <th className="py-2.5 px-3">Slot Time</th>
                <th className="py-2.5 px-3">Carrier</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Assigned Dock</th>
                <th className="py-2.5 px-3">Cargo Details</th>
                <th className="py-2.5 px-3">Pallets</th>
                <th className="py-2.5 px-3">PO Number</th>
                <th className="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-200">
              {appointments.map((appt) => (
                <tr key={appt.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-bold text-cyan-400">{appt.id}</td>
                  <td className="py-2.5 px-3 text-slate-300">{appt.scheduledTime}</td>
                  <td className="py-2.5 px-3 font-sans font-medium text-white">{appt.carrier}</td>
                  <td className="py-2.5 px-3 font-sans">
                    <span className="capitalize">{appt.type.replace('_', ' ')}</span>
                  </td>
                  <td className="py-2.5 px-3 text-cyan-300 font-bold">{appt.dockDoorId}</td>
                  <td className="py-2.5 px-3 font-sans text-slate-400 truncate max-w-xs">{appt.cargoType}</td>
                  <td className="py-2.5 px-3 tabular-nums">{appt.pallets}</td>
                  <td className="py-2.5 px-3 text-slate-400">{appt.poNumber}</td>
                  <td className="py-2.5 px-3 text-right font-sans">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                      appt.status === 'at_dock'
                        ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                        : appt.status === 'checked_in'
                        ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}>
                      {appt.status.replace('_', ' ')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Schedule Appointment Modal */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-lg shadow-2xl p-6">
            <h3 className="text-base font-bold text-white mb-4 pb-2 border-b border-slate-800 flex items-center justify-between">
              <span>Book Carrier Dock Appointment</span>
              <button
                onClick={() => setIsScheduleModalOpen(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </h3>

            <form onSubmit={handleCreateAppointment} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Carrier Name</label>
                  <select
                    value={carrier}
                    onChange={(e) => setCarrier(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:outline-none"
                  >
                    <option value="Knight-Swift">Knight-Swift</option>
                    <option value="J.B. Hunt">J.B. Hunt</option>
                    <option value="Schneider National">Schneider National</option>
                    <option value="Werner Enterprises">Werner Enterprises</option>
                    <option value="Prime Inc.">Prime Inc. (Cold Chain)</option>
                    <option value="FedEx Freight">FedEx Freight</option>
                    <option value="Old Dominion">Old Dominion</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Operation Type</label>
                  <select
                    value={apptType}
                    onChange={(e) => setApptType(e.target.value as 'inbound_unload' | 'outbound_load')}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:outline-none"
                  >
                    <option value="inbound_unload">Inbound Live Unload</option>
                    <option value="outbound_load">Outbound Live Loading</option>
                    <option value="drop_and_hook">Drop and Hook</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Scheduled Time Window</label>
                  <input
                    type="text"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    placeholder="e.g. 02:00 PM"
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Assigned Dock Door</label>
                  <select
                    value={selectedDockId}
                    onChange={(e) => setSelectedDockId(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:outline-none"
                  >
                    {dockDoors.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.id} - {d.name} ({d.type})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Cargo Details / Commodity</label>
                <input
                  type="text"
                  value={cargoType}
                  onChange={(e) => setCargoType(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Pallet Count</label>
                  <input
                    type="number"
                    value={pallets}
                    onChange={(e) => setPallets(Number(e.target.value))}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">PO / Reference #</label>
                  <input
                    type="text"
                    value={poNumber}
                    onChange={(e) => setPoNumber(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-slate-950 bg-cyan-400 hover:bg-cyan-300 font-semibold rounded"
                >
                  Confirm Appointment Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
