import React from 'react';
import { Volume2, VolumeX, PlusCircle, ShieldAlert } from 'lucide-react';
import { sounds } from '../../utils/audio';

export type ActiveTab = 'yard_map' | 'gate_kiosk' | 'dock_schedule' | 'hostler_queue' | 'detention_radar' | 'roi_analytics';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  detentionAlertCount: number;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  onOpenQuickCheckIn: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  detentionAlertCount,
  soundEnabled,
  setSoundEnabled,
  onOpenQuickCheckIn
}) => {
  const toggleSound = () => {
    const next = !soundEnabled;
    sounds.enabled = next;
    setSoundEnabled(next);
    if (next) sounds.playSuccessTone();
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-6 py-3.5 bg-slate-900 border-b border-slate-800 text-slate-100">
      {/* Zone 1: Single text element Brand Title */}
      <div className="flex items-center gap-3">
        <a
          href="#yard_map"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('yard_map');
          }}
          className="text-lg font-bold tracking-tight text-white hover:text-cyan-400 transition-colors"
        >
          DockFlow YMS
        </a>
      </div>

      {/* Zone 2: 6 Clean text navigation links with active state indicator */}
      <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('yard_map')}
          className={`transition-colors hover:text-white ${activeTab === 'yard_map' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400 pb-0.5' : ''}`}
        >
          Yard Grid
        </button>
        <button
          onClick={() => setActiveTab('gate_kiosk')}
          className={`transition-colors hover:text-white ${activeTab === 'gate_kiosk' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400 pb-0.5' : ''}`}
        >
          Gate Automation
        </button>
        <button
          onClick={() => setActiveTab('dock_schedule')}
          className={`transition-colors hover:text-white ${activeTab === 'dock_schedule' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400 pb-0.5' : ''}`}
        >
          Dock Doors
        </button>
        <button
          onClick={() => setActiveTab('hostler_queue')}
          className={`transition-colors hover:text-white ${activeTab === 'hostler_queue' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400 pb-0.5' : ''}`}
        >
          Hostler Dispatch
        </button>
        <button
          onClick={() => setActiveTab('detention_radar')}
          className={`relative transition-colors hover:text-white flex items-center gap-1.5 ${activeTab === 'detention_radar' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400 pb-0.5' : ''}`}
        >
          <span>Detention Radar</span>
          {detentionAlertCount > 0 && (
            <span className="font-mono text-xs px-1.5 py-0.2 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded">
              {detentionAlertCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('roi_analytics')}
          className={`transition-colors hover:text-white ${activeTab === 'roi_analytics' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400 pb-0.5' : ''}`}
        >
          DC ROI & Metrics
        </button>
      </nav>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={toggleSound}
          title={soundEnabled ? 'Mute Audio Signals' : 'Enable Audio Signals'}
          aria-label={soundEnabled ? 'Mute Audio Signals' : 'Enable Audio Signals'}
          className="p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-md transition-colors"
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
        </button>

        <button
          onClick={onOpenQuickCheckIn}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors shadow-sm whitespace-nowrap"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Quick Gate Inbound</span>
        </button>
      </div>
    </header>
  );
};
