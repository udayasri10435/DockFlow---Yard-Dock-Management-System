import React, { useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Clock, 
  Truck, 
  ShieldCheck, 
  Download, 
  Sliders, 
  CheckCircle2,
  FileSpreadsheet,
  Zap
} from 'lucide-react';
import { Trailer, DockDoor } from '../../types/yard';
import { sounds } from '../../utils/audio';

interface RoiAnalyticsViewProps {
  trailers: Trailer[];
  dockDoors: DockDoor[];
}

export const RoiAnalyticsView: React.FC<RoiAnalyticsViewProps> = ({
  trailers,
  dockDoors
}) => {
  // Interactive DC ROI Simulator parameters
  const [trailersPerDay, setTrailersPerDay] = useState<number>(85);
  const [currentMonthlyDetention, setCurrentMonthlyDetention] = useState<number>(32000);
  const [jockeyCount, setJockeyCount] = useState<number>(3);
  const [avgGateWaitMinutes, setAvgGateWaitMinutes] = useState<number>(10);

  // Calculations
  const annualDetentionAvoided = Math.round(currentMonthlyDetention * 12 * 0.88); // 88% reduction
  const annualHostlerEfficiencySavings = Math.round(jockeyCount * 45000 * 0.35); // 35% productivity boost
  const annualGateHoursSaved = Math.round((trailersPerDay * 365 * (avgGateWaitMinutes - 1)) / 60);
  const annualGateLaborSavings = Math.round((annualGateHoursSaved * 28) * 0.4);
  const dockProductivitySavings = Math.round(trailersPerDay * 365 * 18); // 18 dollars saved per load in reduced crew wait time
  
  const totalAnnualSavings = annualDetentionAvoided + annualHostlerEfficiencySavings + annualGateLaborSavings + dockProductivitySavings;
  const estimatedYmsAnnualCost = 38000;
  const netRoiPercent = Math.round(((totalAnnualSavings - estimatedYmsAnnualCost) / estimatedYmsAnnualCost) * 100);
  const paybackMonths = ((estimatedYmsAnnualCost / totalAnnualSavings) * 12).toFixed(1);

  const handleExportManifestCSV = () => {
    sounds.playSuccessTone();
    const headers = ['Trailer ID', 'Carrier', 'Type', 'Status', 'Location', 'Dwell (mins)', 'BOL', 'Cargo', 'Weight (lbs)', 'Driver'];
    const rows = trailers.map(t => [
      t.id,
      t.carrier,
      t.trailerType,
      t.status,
      t.locationId,
      t.dwellMinutes,
      t.bolNumber,
      `"${t.cargoDescription.replace(/"/g, '""')}"`,
      t.weightLbs,
      t.driverName
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `dockflow_yard_manifest_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-lg">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <span>Distribution Center High-ROI Value Realization</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Why YMS is the most overlooked, highest-return investment in modern supply chain infrastructure.
          </p>
        </div>

        <button
          onClick={handleExportManifestCSV}
          className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors shadow-sm whitespace-nowrap"
        >
          <Download className="w-4 h-4" />
          <span>Export Yard Manifest (CSV)</span>
        </button>
      </div>

      {/* 4 Pillars of Value Realization */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Detention Fees Avoided</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            ${annualDetentionAvoided.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Eliminates $85/hr carrier dwell fines by providing real-time alerts at 90 minutes.
          </p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Hostler Jockey Productivity</span>
            <Truck className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">
            +38% Moves/Hr
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Automated task dispatch eliminates bobtailing and lost trailer search delays.
          </p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Gate Turnaround Acceleration</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
            58s vs 8.5m
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Autonomous OCR ANPR camera check-in cuts gate queue by 88% and avoids spillback fines.
          </p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Cold-Chain Spoilage Risk</span>
            <ShieldCheck className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-teal-400 tabular-nums">
            $0 Claims
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Live reefer telematics and shore power monitoring protect temperature-sensitive perishables.
          </p>
        </div>
      </div>

      {/* Interactive DC ROI Calculator */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-lg space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Facility Financial ROI Simulation Calculator
            </h3>
          </div>
          <span className="text-xs text-slate-400">Tailor metrics to your Distribution Center</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Sliders on Left */}
          <div className="lg:col-span-6 space-y-5">
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-300 font-medium">Daily Inbound / Outbound Trailers</span>
                <span className="font-mono text-cyan-400 font-bold tabular-nums">{trailersPerDay} trailers/day</span>
              </div>
              <input
                type="range"
                min="20"
                max="250"
                step="5"
                value={trailersPerDay}
                onChange={(e) => setTrailersPerDay(Number(e.target.value))}
                className="w-full accent-cyan-400"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-300 font-medium">Current Monthly Detention Penalty Spend</span>
                <span className="font-mono text-rose-400 font-bold tabular-nums">${currentMonthlyDetention.toLocaleString()}/mo</span>
              </div>
              <input
                type="range"
                min="5000"
                max="100000"
                step="2500"
                value={currentMonthlyDetention}
                onChange={(e) => setCurrentMonthlyDetention(Number(e.target.value))}
                className="w-full accent-rose-400"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-300 font-medium">Hostler Yard Jockey Vehicles in Operation</span>
                <span className="font-mono text-amber-400 font-bold tabular-nums">{jockeyCount} jockeys</span>
              </div>
              <input
                type="range"
                min="1"
                max="8"
                step="1"
                value={jockeyCount}
                onChange={(e) => setJockeyCount(Number(e.target.value))}
                className="w-full accent-amber-400"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-slate-300 font-medium">Current Manual Gate Wait Duration</span>
                <span className="font-mono text-slate-200 font-bold tabular-nums">{avgGateWaitMinutes} minutes / truck</span>
              </div>
              <input
                type="range"
                min="4"
                max="25"
                step="1"
                value={avgGateWaitMinutes}
                onChange={(e) => setAvgGateWaitMinutes(Number(e.target.value))}
                className="w-full accent-cyan-400"
              />
            </div>
          </div>

          {/* Computed Results on Right */}
          <div className="lg:col-span-6 bg-slate-950 p-6 rounded-lg border border-slate-800 flex flex-col justify-between space-y-5">
            <div>
              <span className="text-xs font-mono uppercase text-slate-400 block mb-1">
                Projected Net Annual Operational Savings
              </span>
              <div className="text-4xl font-extrabold font-mono text-emerald-400 tabular-nums">
                ${totalAnnualSavings.toLocaleString()}
                <span className="text-xs text-slate-400 font-normal ml-2">/ year</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 py-3 border-y border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 block">Est. Payback Timeline</span>
                <span className="text-xl font-bold font-mono text-white tabular-nums">{paybackMonths} months</span>
              </div>
              <div>
                <span className="text-slate-400 block">Return on Investment (ROI)</span>
                <span className="text-xl font-bold font-mono text-emerald-400 tabular-nums">+{netRoiPercent}%</span>
              </div>
              <div>
                <span className="text-slate-400 block">Driver Hours Saved Annually</span>
                <span className="text-xl font-bold font-mono text-cyan-300 tabular-nums">{annualGateHoursSaved.toLocaleString()} hrs</span>
              </div>
              <div>
                <span className="text-slate-400 block">Dock Starvation Reduced</span>
                <span className="text-xl font-bold font-mono text-cyan-300 tabular-nums">-94% idle time</span>
              </div>
            </div>

            <div className="text-xs text-slate-400 leading-relaxed">
              Based on empirical distribution center case studies across North American retail, food service, and manufacturing hubs.
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
