import React from 'react';
import { 
  AlertTriangle, 
  Clock, 
  DollarSign, 
  ArrowRight, 
  ShieldCheck, 
  Thermometer, 
  Zap, 
  TrendingDown,
  Sparkles
} from 'lucide-react';
import { Trailer, DockDoor } from '../../types/yard';
import { formatMinutes, calculateDetentionAccrued, getDetentionStatus } from '../../utils/helpers';
import { sounds } from '../../utils/audio';

interface DetentionRadarViewProps {
  trailers: Trailer[];
  dockDoors: DockDoor[];
  onExpediteMove: (trailer: Trailer) => void;
  onSelectTrailer: (trailer: Trailer) => void;
}

export const DetentionRadarView: React.FC<DetentionRadarViewProps> = ({
  trailers,
  dockDoors,
  onExpediteMove,
  onSelectTrailer
}) => {
  // Sort trailers by detention urgency: highest overtime or closest to 120 mins first
  const sortedTrailers = [...trailers].sort((a, b) => {
    const aRemaining = a.freeTimeLimitMinutes - a.dwellMinutes;
    const bRemaining = b.freeTimeLimitMinutes - b.dwellMinutes;
    return aRemaining - bRemaining;
  });

  const detentionActive = sortedTrailers.filter(t => t.dwellMinutes > t.freeTimeLimitMinutes);
  const detentionWarning = sortedTrailers.filter(t => {
    const rem = t.freeTimeLimitMinutes - t.dwellMinutes;
    return rem > 0 && rem <= 30;
  });
  const detentionNominal = sortedTrailers.filter(t => {
    return (t.freeTimeLimitMinutes - t.dwellMinutes) > 30;
  });

  const totalAccruedDollars = detentionActive.reduce((acc, t) => {
    return acc + calculateDetentionAccrued(t.dwellMinutes, t.freeTimeLimitMinutes, t.detentionRatePerHour);
  }, 0);

  const atRiskPotentialDollars = detentionWarning.length * 85;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-lg">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-amber-400" />
            <span>Carrier Detention Risk Radar & Telematics Protection</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time dwell tracking against standard 2-hour free time window. Eliminates $300k+ in annual carrier fees.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 rounded text-amber-300 text-xs font-mono font-bold">
            STANDARD FREE TIME: 120 MINS
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Current Detention Liability</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-rose-400 tabular-nums">
              ${totalAccruedDollars.toLocaleString()}
            </span>
            <span className="text-xs text-slate-500 font-mono">active accrued</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">{detentionActive.length} trailers over 2-hr threshold</span>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Imminent Fee Risk (&lt;30m)</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
              ${atRiskPotentialDollars.toLocaleString()}
            </span>
            <span className="text-xs text-amber-300 font-mono">{detentionWarning.length} trailers</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Requires priority spot to dock door</span>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Detention Avoided This Month</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">$42,850</span>
            <span className="text-xs text-emerald-400 font-mono">-92% Fees</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Audited against carrier rate agreements</span>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Avg Trailer Turn Time (TAT)</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">54 mins</span>
            <span className="text-xs text-cyan-400 font-mono">Well within 120m</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Distribution center benchmark</span>
        </div>
      </div>

      {/* Critical Overdue Section */}
      {detentionActive.length > 0 && (
        <div className="p-4 bg-rose-950/20 border border-rose-900/60 rounded-lg space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-rose-900/40">
            <div className="flex items-center gap-2 text-rose-400">
              <AlertTriangle className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider font-mono">
                CRITICAL DETENTION PENALTY ACTIVE ({detentionActive.length} Trailers)
              </h3>
            </div>
            <span className="text-xs text-rose-300 font-mono">
              Total Rate: ${(detentionActive.reduce((a, t) => a + t.detentionRatePerHour, 0))}/hr
            </span>
          </div>

          <div className="space-y-2">
            {detentionActive.map((trailer) => {
              const fee = calculateDetentionAccrued(trailer.dwellMinutes, trailer.freeTimeLimitMinutes, trailer.detentionRatePerHour);
              const overtime = trailer.dwellMinutes - trailer.freeTimeLimitMinutes;

              return (
                <div
                  key={trailer.id}
                  className="p-3 bg-slate-900 border border-rose-800/80 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-white">{trailer.id}</span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-xs font-semibold text-slate-200">{trailer.carrier}</span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-xs font-mono text-cyan-400">Spot {trailer.locationId}</span>
                    </div>
                    <div className="text-xs text-slate-300">
                      {trailer.cargoDescription}
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <span className="text-[10px] font-mono uppercase text-rose-400 block font-bold">
                        +{overtime}m OVERDUE
                      </span>
                      <span className="text-sm font-mono font-bold text-rose-400">
                        ${fee} <span className="text-[10px] text-slate-400 font-normal">(@${trailer.detentionRatePerHour}/hr)</span>
                      </span>
                    </div>

                    <button
                      onClick={() => onExpediteMove(trailer)}
                      className="px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-rose-400 hover:bg-rose-300 rounded transition-colors whitespace-nowrap"
                    >
                      Expedite Move to Dock
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Warning Tier: <30 mins left */}
      {detentionWarning.length > 0 && (
        <div className="p-4 bg-amber-950/20 border border-amber-900/60 rounded-lg space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-amber-900/40">
            <div className="flex items-center gap-2 text-amber-400">
              <Clock className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-wider font-mono">
                WARNING: DETENTION FEE APPROACHING IN &lt; 30 MINS ({detentionWarning.length} Trailers)
              </h3>
            </div>
            <span className="text-xs text-amber-300 font-mono">Action Recommended</span>
          </div>

          <div className="space-y-2">
            {detentionWarning.map((trailer) => {
              const minutesLeft = trailer.freeTimeLimitMinutes - trailer.dwellMinutes;

              return (
                <div
                  key={trailer.id}
                  className="p-3 bg-slate-900 border border-amber-800/80 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-white">{trailer.id}</span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-xs font-semibold text-slate-200">{trailer.carrier}</span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-xs font-mono text-cyan-400">Spot {trailer.locationId}</span>
                    </div>
                    <div className="text-xs text-slate-300">
                      {trailer.cargoDescription}
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <span className="text-[10px] font-mono uppercase text-amber-400 block font-bold">
                        {minutesLeft}m REMAINING
                      </span>
                      <span className="text-xs font-mono text-slate-400">
                        Fee starts at 120m
                      </span>
                    </div>

                    <button
                      onClick={() => onExpediteMove(trailer)}
                      className="px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap"
                    >
                      Prioritize Dock Door
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Reefer Cold-Chain Spoilage Watchlist */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <Thermometer className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Cold-Chain Reefer Telematics Watchlist
            </h3>
          </div>
          <span className="text-xs text-teal-400 font-mono">
            Zero Temperature Deviations Tolerated
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {trailers.filter(t => t.reefer).map((trailer) => {
            const reefer = trailer.reefer!;
            const isTempAlert = Math.abs(reefer.currentTempF - reefer.setPointF) > 2;
            const isFuelLow = reefer.fuelLevelPercent < 25;

            return (
              <div
                key={trailer.id}
                onClick={() => onSelectTrailer(trailer)}
                className={`p-3 bg-slate-950 border rounded-lg cursor-pointer hover:border-teal-400 transition-all ${
                  isFuelLow ? 'border-amber-700' : 'border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                  <span className="font-mono text-xs font-bold text-white">{trailer.id}</span>
                  <span className="text-[10px] text-teal-400 font-mono">{trailer.locationId}</span>
                </div>

                <div className="my-2 space-y-1">
                  <div className="text-xs text-slate-300 truncate">{trailer.carrier}</div>
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs text-slate-400">Temp:</span>
                    <span className={`text-base font-bold font-mono ${isTempAlert ? 'text-rose-400' : 'text-teal-300'}`}>
                      {reefer.currentTempF > 0 ? `+${reefer.currentTempF}` : reefer.currentTempF}°F
                    </span>
                  </div>
                  <div className="flex items-baseline justify-between text-xs">
                    <span className="text-slate-400">Target:</span>
                    <span className="font-mono text-slate-300">
                      {reefer.setPointF > 0 ? `+${reefer.setPointF}` : reefer.setPointF}°F
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] font-mono">
                  <span className={isFuelLow ? 'text-rose-400 font-bold' : 'text-slate-400'}>
                    Fuel: {reefer.fuelLevelPercent}%
                  </span>
                  <span className="text-emerald-400">
                    {reefer.pluggedIn ? 'Shore Grid' : 'Diesel'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
