import React, { useState } from 'react';
import { 
  Truck, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Plus, 
  Radio, 
  Tablet, 
  Flame, 
  ShieldAlert,
  Zap,
  Check
} from 'lucide-react';
import { HostlerTask, Trailer, DockDoor, YardSpot } from '../../types/yard';
import { sounds } from '../../utils/audio';

interface HostlerDispatchViewProps {
  tasks: HostlerTask[];
  trailers: Trailer[];
  dockDoors: DockDoor[];
  yardSpots: YardSpot[];
  onUpdateTaskStatus: (taskId: string, newStatus: 'assigned' | 'hooked' | 'completed') => void;
  onCreateTask: (newTask: HostlerTask) => void;
}

export const HostlerDispatchView: React.FC<HostlerDispatchViewProps> = ({
  tasks,
  trailers,
  dockDoors,
  yardSpots,
  onUpdateTaskStatus,
  onCreateTask
}) => {
  const [activeMode, setActiveMode] = useState<'dispatcher' | 'incab'>('dispatcher');
  const [selectedJockey, setSelectedJockey] = useState<'Jockey-01 (Mac)' | 'Jockey-02 (Sam)'>('Jockey-01 (Mac)');
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState(false);

  // New task form state
  const [trailerId, setTrailerId] = useState(trailers[0]?.id || 'TLR-1120');
  const [fromLoc, setFromLoc] = useState('A-01');
  const [toLoc, setToLoc] = useState('D-03');
  const [priority, setPriority] = useState<'urgent' | 'high' | 'normal'>('urgent');
  const [reason, setReason] = useState('Expedite move to prevent carrier detention fee');

  const pendingTasks = tasks.filter(t => t.status !== 'completed');
  const completedTasks = tasks.filter(t => t.status === 'completed');

  // For in-cab tablet view
  const activeInCabTask = pendingTasks.find(t => t.assignedHostler?.includes(selectedJockey.split(' ')[0])) || pendingTasks[0];

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    const trailer = trailers.find(t => t.id === trailerId);
    const newTask: HostlerTask = {
      id: `TSK-${Math.floor(410 + Math.random() * 500)}`,
      trailerId,
      carrier: trailer ? trailer.carrier : 'Carrier Freight',
      taskType: toLoc.startsWith('D-') ? 'spot_to_dock' : toLoc.startsWith('A-') || toLoc.startsWith('B-') ? 'dock_to_spot' : 'reefer_fuel_plug',
      fromLocation: fromLoc,
      toLocation: toLoc,
      priority,
      status: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      reason,
      detentionSavings: priority === 'urgent' ? 170 : 85
    };
    onCreateTask(newTask);
    sounds.playRadioChirp();
    setIsNewTaskModalOpen(false);
  };

  const handleAdvanceTask = (taskId: string, currentStatus: HostlerTask['status']) => {
    if (currentStatus === 'pending') {
      onUpdateTaskStatus(taskId, 'assigned');
      sounds.playRadioChirp();
    } else if (currentStatus === 'assigned') {
      onUpdateTaskStatus(taskId, 'hooked');
      sounds.playSuccessTone();
    } else if (currentStatus === 'hooked') {
      onUpdateTaskStatus(taskId, 'completed');
      sounds.playSuccessTone();
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Mode Toggle */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-lg">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Truck className="w-5 h-5 text-cyan-400" />
            <span>Hostler / Yard Jockey Dispatch Queue</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated task dispatch prioritizing dock starvation prevention & detention fee mitigation.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* View mode toggle */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
            <button
              onClick={() => setActiveMode('dispatcher')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded transition-colors ${
                activeMode === 'dispatcher' ? 'bg-slate-800 text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Dispatcher Desk</span>
            </button>
            <button
              onClick={() => setActiveMode('incab')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded transition-colors ${
                activeMode === 'incab' ? 'bg-slate-800 text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Tablet className="w-3.5 h-3.5" />
              <span>In-Cab Tablet Mode</span>
            </button>
          </div>

          <button
            onClick={() => setIsNewTaskModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors shadow-sm whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>+ Create Move Order</span>
          </button>
        </div>
      </div>

      {/* KPI Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Pending Yard Moves</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">{pendingTasks.length}</span>
            <span className="text-xs text-amber-400 font-mono">
              {pendingTasks.filter(t => t.priority === 'urgent').length} Urgent
            </span>
          </div>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Avg Move Cycle Time</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">6.2 min</span>
            <span className="text-xs text-emerald-400 font-mono">Industry Top 5%</span>
          </div>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Moves Completed Today</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {38 + completedTasks.length}
            </span>
            <span className="text-xs text-cyan-400 font-mono">+35% vs Radio</span>
          </div>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Detention Penalties Prevented</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
              ${(3250 + completedTasks.reduce((acc, t) => acc + t.detentionSavings, 0)).toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* DISPATCHER DESK MODE */}
      {activeMode === 'dispatcher' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Pending Tasks Queue */}
          <div className="lg:col-span-8 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Active Move Queue (Priority Ordered)
              </span>
              <span className="text-xs text-slate-400">
                {pendingTasks.length} moves in progress
              </span>
            </div>

            {pendingTasks.length === 0 ? (
              <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-lg text-slate-400 text-xs">
                All hostler tasks completed! Yard moves are clear.
              </div>
            ) : (
              pendingTasks.map((task) => (
                <div
                  key={task.id}
                  className={`p-4 bg-slate-900 border rounded-lg transition-all ${
                    task.priority === 'urgent'
                      ? 'border-amber-700/80 bg-amber-950/10'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold ${
                          task.priority === 'urgent'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-slate-800 text-slate-300'
                        }`}>
                          {task.priority}
                        </span>
                        <span className="font-mono text-xs font-bold text-white">{task.id}</span>
                        <span className="text-xs text-slate-400">·</span>
                        <span className="font-mono text-xs font-bold text-cyan-300">{task.trailerId}</span>
                        <span className="text-xs text-slate-400">({task.carrier})</span>
                      </div>

                      <div className="text-xs text-slate-300">
                        {task.reason}
                      </div>

                      {/* Route Path Indicator */}
                      <div className="flex items-center gap-3 pt-2 text-xs font-mono">
                        <div className="flex items-center gap-2 bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
                          <span className="text-slate-400 text-[10px]">FROM:</span>
                          <span className="text-white font-bold">{task.fromLocation}</span>
                        </div>
                        <ArrowRight className="w-4 h-4 text-cyan-400 shrink-0" />
                        <div className="flex items-center gap-2 bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
                          <span className="text-slate-400 text-[10px]">TO:</span>
                          <span className="text-cyan-300 font-bold">{task.toLocation}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="text-right space-y-2 shrink-0">
                      <div className="text-[11px] font-mono text-slate-400">
                        {task.assignedHostler ? (
                          <span className="text-cyan-400 font-semibold">{task.assignedHostler}</span>
                        ) : (
                          <span className="text-slate-500">Unassigned</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {task.status === 'pending' && (
                          <button
                            onClick={() => handleAdvanceTask(task.id, 'pending')}
                            className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
                          >
                            Assign Jockey
                          </button>
                        )}

                        {task.status === 'assigned' && (
                          <button
                            onClick={() => handleAdvanceTask(task.id, 'assigned')}
                            className="px-3 py-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded transition-colors"
                          >
                            Mark Hooked
                          </button>
                        )}

                        {task.status === 'hooked' && (
                          <button
                            onClick={() => handleAdvanceTask(task.id, 'hooked')}
                            className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded transition-colors flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Mark Spotted</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Hostler Fleet Telematics & Status */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-4">
              <span className="text-xs font-bold text-white uppercase tracking-wider font-mono block pb-2 border-b border-slate-800">
                Active Yard Jockey Equipment
              </span>

              {/* Truck 1 */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-bold text-white">Truck #H-01 (Ottawa T2)</span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 font-semibold bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-800/80">
                    EN ROUTE
                  </span>
                </div>
                <div className="text-xs text-slate-300">
                  Driver: <span className="font-semibold text-white">Mac Reynolds</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  Current Move: <span className="font-mono text-cyan-300">TLR-1120 → D-03</span>
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-1 border-t border-slate-800">
                  <span>Fuel: 78%</span>
                  <span>14 Moves Shift</span>
                </div>
              </div>

              {/* Truck 2 */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-amber-400" />
                    <span className="text-xs font-bold text-white">Truck #H-02 (T-Rex Spotter)</span>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-400 font-semibold bg-cyan-950/40 px-1.5 py-0.5 rounded border border-cyan-800/80">
                    STANDBY
                  </span>
                </div>
                <div className="text-xs text-slate-300">
                  Driver: <span className="font-semibold text-white">Sam Alvarez</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  Current Move: <span className="font-mono text-slate-400">Awaiting Assignment</span>
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-1 border-t border-slate-800">
                  <span>Fuel: 85%</span>
                  <span>11 Moves Shift</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      ) : (
        /* IN-CAB TABLET TERMINAL MODE */
        <div className="max-w-2xl mx-auto bg-slate-950 border-4 border-slate-800 rounded-2xl p-6 shadow-2xl space-y-6">
          
          {/* Rugged Tablet Header */}
          <div className="flex items-center justify-between pb-4 border-b-2 border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-cyan-500/20 text-cyan-400 rounded-lg border border-cyan-500/40">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-base font-bold text-white font-mono">RUGGED CAB TERMINAL</span>
                <span className="text-xs text-slate-400 block font-mono">
                  TRUCK #H-01 · DRIVER: MAC REYNOLDS
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs font-mono text-emerald-400 font-bold block">GPS ONLINE</span>
              <span className="text-xs font-mono text-slate-400">YARD WIFI: STRONG</span>
            </div>
          </div>

          {/* Active Job Card */}
          {activeInCabTask ? (
            <div className="p-6 bg-slate-900 border-2 border-cyan-500/60 rounded-xl space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase font-bold text-amber-400 bg-amber-950/60 px-2.5 py-1 rounded border border-amber-800">
                  {activeInCabTask.priority} PRIORITY MOVE ORDER
                </span>
                <span className="text-sm font-mono text-slate-400">#{activeInCabTask.id}</span>
              </div>

              <div>
                <span className="text-xs text-slate-400 block mb-1">TARGET TRAILER</span>
                <span className="text-3xl font-extrabold font-mono text-white tracking-wider block">
                  {activeInCabTask.trailerId}
                </span>
                <span className="text-sm text-cyan-300 font-medium">{activeInCabTask.carrier}</span>
              </div>

              {/* Waypoints */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950 rounded-lg border border-slate-800">
                  <span className="text-xs font-mono text-slate-400 block">PICKUP FROM:</span>
                  <span className="text-2xl font-bold font-mono text-white mt-1 block">
                    {activeInCabTask.fromLocation}
                  </span>
                </div>
                <div className="p-4 bg-slate-950 rounded-lg border border-cyan-800">
                  <span className="text-xs font-mono text-cyan-400 block">DELIVER SPOT TO:</span>
                  <span className="text-2xl font-bold font-mono text-cyan-300 mt-1 block">
                    {activeInCabTask.toLocation}
                  </span>
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 rounded border border-slate-800 text-xs text-slate-300">
                <span className="text-slate-400 font-semibold">Special Instructions:</span>{' '}
                {activeInCabTask.reason}
              </div>

              {/* Big Rugged Action Buttons */}
              <div className="pt-2 grid grid-cols-2 gap-3">
                {activeInCabTask.status !== 'hooked' ? (
                  <button
                    onClick={() => handleAdvanceTask(activeInCabTask.id, 'assigned')}
                    className="py-4 px-6 text-sm font-bold uppercase tracking-wider text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2"
                  >
                    <Truck className="w-5 h-5" />
                    <span>Confirm 5th Wheel Hooked</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleAdvanceTask(activeInCabTask.id, 'hooked')}
                    className="py-4 px-6 text-sm font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 col-span-2"
                  >
                    <CheckCircle2 className="w-6 h-6" />
                    <span>Spotted & Unhooked at {activeInCabTask.toLocation}</span>
                  </button>
                )}

                {activeInCabTask.status !== 'hooked' && (
                  <button
                    onClick={() => alert('Dispatcher notified of obstacle in lane.')}
                    className="py-4 px-6 text-xs font-bold uppercase tracking-wider text-rose-300 bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/80 rounded-xl transition-all"
                  >
                    Report Obstacle / Blocked
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-xl space-y-3">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
              <span className="text-base font-bold text-white block">Queue Empty</span>
              <span className="text-xs text-slate-400 block">No pending moves assigned to your cab. Stand by at staging lane.</span>
            </div>
          )}

        </div>
      )}

      {/* Create Move Task Modal */}
      {isNewTaskModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-lg shadow-2xl p-6">
            <h3 className="text-base font-bold text-white mb-4 pb-2 border-b border-slate-800 flex items-center justify-between">
              <span>Manual Hostler Move Dispatch</span>
              <button
                onClick={() => setIsNewTaskModalOpen(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </h3>

            <form onSubmit={handleCreateTask} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Select Trailer</label>
                <select
                  value={trailerId}
                  onChange={(e) => {
                    setTrailerId(e.target.value);
                    const t = trailers.find(tr => tr.id === e.target.value);
                    if (t) setFromLoc(t.locationId);
                  }}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:outline-none"
                >
                  {trailers.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.id} · {t.carrier} · Currently at {t.locationId}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Source Location</label>
                  <input
                    type="text"
                    value={fromLoc}
                    onChange={(e) => setFromLoc(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Target Destination</label>
                  <select
                    value={toLoc}
                    onChange={(e) => setToLoc(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:outline-none"
                  >
                    <optgroup label="Dock Doors">
                      {dockDoors.map(d => (
                        <option key={d.id} value={d.id}>
                          {d.id} ({d.status})
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="Yard Staging Spots">
                      {yardSpots.filter(s => !s.occupiedTrailerId).map(s => (
                        <option key={s.id} value={s.id}>
                          Spot {s.id} ({s.zone})
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as 'urgent' | 'high' | 'normal')}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:outline-none"
                  >
                    <option value="urgent">Urgent (Detention / Starving Dock)</option>
                    <option value="high">High</option>
                    <option value="normal">Normal</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Reason / Order Code</label>
                  <input
                    type="text"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewTaskModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-slate-950 bg-cyan-400 hover:bg-cyan-300 font-semibold rounded"
                >
                  Broadcast Move Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
