import React, { useState } from 'react';
import { 
  Camera, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  ShieldCheck, 
  QrCode, 
  Printer, 
  Clock, 
  Truck, 
  RefreshCw,
  Sparkles,
  Zap,
  ExternalLink
} from 'lucide-react';
import { GateLane, GateLogEntry, Trailer, DockDoor, YardSpot } from '../../types/yard';
import { sounds } from '../../utils/audio';

interface GateKioskViewProps {
  gateLanes: GateLane[];
  gateLogs: GateLogEntry[];
  trailers: Trailer[];
  dockDoors: DockDoor[];
  yardSpots: YardSpot[];
  onCheckInTrailer: (newTrailer: Trailer, assignedSpotOrDock: string, logEntry: GateLogEntry) => void;
  onDepartTrailer: (trailerId: string) => void;
}

export const GateKioskView: React.FC<GateKioskViewProps> = ({
  gateLanes,
  gateLogs,
  trailers,
  dockDoors,
  yardSpots,
  onCheckInTrailer,
  onDepartTrailer
}) => {
  const [selectedLaneId, setSelectedLaneId] = useState<string>('GATE-IN-1');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [gatePassIssued, setGatePassIssued] = useState<{
    trailerId: string;
    carrier: string;
    destination: string;
    driverName: string;
    passCode: string;
    timestamp: string;
  } | null>(null);

  // Form state for manual or auto-fill check in
  const [tractorPlate, setTractorPlate] = useState<string>('IL-884-JBH');
  const [trailerId, setTrailerId] = useState<string>('TLR-9512');
  const [carrier, setCarrier] = useState<string>('J.B. Hunt');
  const [driverName, setDriverName] = useState<string>('Mateo Sanchez');
  const [driverPhone, setDriverPhone] = useState<string>('(312) 555-8941');
  const [bolNumber, setBolNumber] = useState<string>('BOL-JBH-88421');
  const [cargoDesc, setCargoDesc] = useState<string>('Commercial Lighting Fixtures');
  const [trailerType, setTrailerType] = useState<'dry_van_53' | 'reefer_53'>('dry_van_53');
  const [sealNumber, setSealNumber] = useState<string>('SL-663810');
  const [sealVerified, setSealVerified] = useState<boolean>(true);
  const [assignedDestination, setAssignedDestination] = useState<string>('D-03');
  const [barrierState, setBarrierState] = useState<'closed' | 'open' | 'opening'>('closed');

  // Outbound selector
  const [outboundTrailerId, setOutboundTrailerId] = useState<string>('');

  const readyOutboundTrailers = trailers.filter(t => t.status === 'outbound_ready' || t.status === 'empty_staged');

  const handleSimulateOCRScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      sounds.playSuccessTone();
      setTractorPlate('TX-774-WRN');
      setTrailerId('TLR-4190');
      setCarrier('Werner Enterprises');
      setDriverName('Carlos Mendez');
      setDriverPhone('(210) 555-4089');
      setBolNumber('BOL-WRN-77419');
      setCargoDesc('Plumbing Fixtures & Industrial Valves');
      setSealNumber('SL-993411');
      setSealVerified(true);
      // Pick best available dock door or open yard spot
      const openDock = dockDoors.find(d => d.status === 'available');
      if (openDock) {
        setAssignedDestination(openDock.id);
      } else {
        const openSpot = yardSpots.find(s => !s.occupiedTrailerId);
        setAssignedDestination(openSpot ? openSpot.id : 'A-03');
      }
    }, 900);
  };

  const handleAuthorizeCheckIn = () => {
    if (!trailerId || !assignedDestination) return;

    // Trigger barrier arm opening animation & chime
    setBarrierState('opening');
    sounds.playGateChime();

    setTimeout(() => {
      setBarrierState('open');

      const passCode = `GP-${Math.floor(100000 + Math.random() * 900000)}`;
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const newTrailer: Trailer = {
        id: trailerId,
        carrier,
        trailerType,
        status: assignedDestination.startsWith('D-') ? 'docked' : 'yard_staged',
        locationType: assignedDestination.startsWith('D-') ? 'dock_door' : 'yard_spot',
        locationId: assignedDestination,
        cargoDescription: cargoDesc,
        weightLbs: 34500,
        palletsCount: 24,
        sealNumber,
        isSealed: sealVerified,
        checkInTime: now.toISOString(),
        dwellMinutes: 1,
        freeTimeLimitMinutes: 120,
        detentionRatePerHour: 85,
        bolNumber,
        driverName,
        driverPhone,
        tractorPlate,
        priority: 'normal'
      };

      const newLog: GateLogEntry = {
        id: `GL-${Math.floor(9030 + Math.random() * 900)}`,
        timestamp: timeStr,
        trailerId,
        carrier,
        driverName,
        action: 'check_in',
        assignedLocation: assignedDestination.startsWith('D-') ? `Dock Door ${assignedDestination.replace('D-', '')}` : `Spot ${assignedDestination}`,
        durationSeconds: 52,
        bolNumber,
        status: 'cleared'
      };

      onCheckInTrailer(newTrailer, assignedDestination, newLog);

      setGatePassIssued({
        trailerId,
        carrier,
        destination: assignedDestination,
        driverName,
        passCode,
        timestamp: timeStr
      });

      // Auto-reset barrier after 5 seconds
      setTimeout(() => {
        setBarrierState('closed');
      }, 5000);
    }, 600);
  };

  const handleExecuteOutboundDeparture = () => {
    if (!outboundTrailerId) return;
    const trailer = trailers.find(t => t.id === outboundTrailerId);
    if (!trailer) return;

    setBarrierState('opening');
    sounds.playGateChime();

    setTimeout(() => {
      setBarrierState('open');
      onDepartTrailer(outboundTrailerId);
      setOutboundTrailerId('');

      setTimeout(() => {
        setBarrierState('closed');
      }, 4000);
    }, 500);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Gate Automation ROI stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Avg Gate Check-in Time</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">58 sec</span>
            <span className="text-xs text-emerald-400 font-mono">-88% vs Manual</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Legacy clipboard check-in was 8.5 min</span>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Daily Gate Throughput</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">54 / hr max</span>
            <span className="text-xs text-cyan-400 font-mono">Zero Spillback</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Highway queue fine risk eliminated</span>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">ANPR OCR Accuracy</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">99.4%</span>
            <span className="text-xs text-slate-500">Autonomous</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">High-speed plate & stencil recognition</span>
        </div>

        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg">
          <span className="text-xs text-slate-400 block">Barrier Arm Status</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className={`text-xl font-bold font-mono uppercase ${
              barrierState === 'open' ? 'text-emerald-400' : barrierState === 'opening' ? 'text-amber-400' : 'text-slate-300'
            }`}>
              {barrierState === 'opening' ? 'Lifting Arm...' : barrierState === 'open' ? 'ARM OPEN' : 'ARM SECURED'}
            </span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">RFID Interlock Active</span>
        </div>
      </div>

      {/* Main Console & Camera OCR View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Simulated Camera Feed & OCR Scanner */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
            
            {/* Camera Viewport Header */}
            <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                  CAMERA CAM-G1 · INBOUND APPROACH LANE 1
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                <span>ANPR OCR ONLINE</span>
                <span>·</span>
                <span>30 FPS</span>
              </div>
            </div>

            {/* Visual Simulated Camera Screen */}
            <div className="relative aspect-video bg-slate-950 flex flex-col items-center justify-center p-6 border-b border-slate-800 overflow-hidden">
              
              {/* Camera Grid Lines Overlay */}
              <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none opacity-20 border border-cyan-500/40">
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
                <div className="border border-cyan-500/20"></div>
              </div>

              {/* Truck Graphic Representation */}
              <div className="relative z-10 flex flex-col items-center text-center max-w-md w-full">
                <div className="p-4 bg-slate-900/90 border border-slate-700 rounded-lg shadow-xl w-full">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
                    <span className="text-[11px] font-mono text-cyan-400 flex items-center gap-1.5">
                      <Camera className="w-3.5 h-3.5" /> Optical Recognition Target Locked
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/80">
                      MATCH CONFIRMED
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-left">
                    <div className="p-2 bg-slate-950 border border-cyan-500/40 rounded relative">
                      <span className="text-[9px] font-mono uppercase text-cyan-400 block">Tractor Plate OCR</span>
                      <span className="text-base font-bold font-mono text-white tracking-widest block">{tractorPlate}</span>
                      <span className="text-[10px] text-emerald-400 font-mono">Conf: 99.8%</span>
                    </div>

                    <div className="p-2 bg-slate-950 border border-cyan-500/40 rounded relative">
                      <span className="text-[9px] font-mono uppercase text-cyan-400 block">Trailer Stencil OCR</span>
                      <span className="text-base font-bold font-mono text-white tracking-widest block">{trailerId}</span>
                      <span className="text-[10px] text-emerald-400 font-mono">Conf: 99.1%</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
                    <div className="flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-cyan-400" />
                      <span>{carrier}</span>
                      <span className="text-slate-500">·</span>
                      <span className="text-slate-400">{driverName}</span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-400">
                      BOL: <span className="text-slate-200">{bolNumber}</span>
                    </div>
                  </div>
                </div>

                {/* Animated Barrier State Indicator */}
                <div className="mt-4 flex items-center gap-3">
                  <div className={`px-4 py-1.5 rounded-full text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
                    barrierState === 'open'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                      : barrierState === 'opening'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 animate-pulse'
                      : 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${
                      barrierState === 'open' ? 'bg-emerald-400' : barrierState === 'opening' ? 'bg-amber-400' : 'bg-rose-400'
                    }`}></span>
                    {barrierState === 'open' ? 'BARRIER LIFTED · VEHICLE CLEAR TO ENTER' : barrierState === 'opening' ? 'LIFTING GATE BARRIER...' : 'BARRIER DOWN · COMPLETE CLEARANCE'}
                  </div>
                </div>
              </div>

              {/* Bottom camera controls */}
              <div className="absolute bottom-2 left-4 right-4 flex items-center justify-between text-[11px] text-slate-400">
                <span>LANE 1: EXPRESS RFID/ANPR</span>
                <button
                  onClick={handleSimulateOCRScan}
                  disabled={isScanning}
                  className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                  <span>Simulate Next Arriving Truck</span>
                </button>
              </div>
            </div>

            {/* Gate Pass Modal / Issued Card */}
            {gatePassIssued && (
              <div className="p-4 bg-emerald-950/20 border-t border-emerald-900/60 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-emerald-900/40 border border-emerald-700/60 rounded text-emerald-400">
                    <QrCode className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-xs font-mono text-emerald-400 font-bold block">
                      DIGITAL GATE PASS GENERATED · {gatePassIssued.passCode}
                    </span>
                    <span className="text-sm font-semibold text-white">
                      Directed to <span className="text-cyan-400 font-mono font-bold">{gatePassIssued.destination}</span>
                    </span>
                    <span className="text-xs text-slate-400 ml-2">({gatePassIssued.carrier} · Driver {gatePassIssued.driverName})</span>
                  </div>
                </div>

                <button
                  onClick={() => alert(`Printing Gate Dispatch Pass #${gatePassIssued.passCode} for driver ${gatePassIssued.driverName}.\nRouting: Proceed immediately to ${gatePassIssued.destination}.`)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors whitespace-nowrap"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Driver Slip</span>
                </button>
              </div>
            )}
          </div>

          {/* Outbound Gate Clearance Panel */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <ArrowRight className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  Gate 3 · Outbound Clearance & Departure
                </h4>
              </div>
              <span className="text-xs text-slate-400">Automated Seal & BOL Sign-off</span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <div className="flex-1 w-full">
                <select
                  value={outboundTrailerId}
                  onChange={(e) => setOutboundTrailerId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded text-slate-200 focus:border-cyan-400 focus:outline-none font-mono"
                >
                  <option value="">Select Trailer Departing Facility...</option>
                  {readyOutboundTrailers.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.id} · {t.carrier} · Spot {t.locationId} ({t.cargoDescription.slice(0, 32)})
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleExecuteOutboundDeparture}
                disabled={!outboundTrailerId}
                className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed rounded transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Verify Seal & Clear Gate</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Check-in Clearance & Decision Routing Form */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 pb-2 border-b border-slate-800 flex items-center justify-between">
              <span>Gate Inbound Verification</span>
              <span className="text-xs font-mono text-cyan-400">Automated Match</span>
            </h3>

            <div className="space-y-4 text-xs">
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-mono">Tractor Plate</label>
                  <input
                    type="text"
                    value={tractorPlate}
                    onChange={(e) => setTractorPlate(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1 font-mono">Trailer Stencil #</label>
                  <input
                    type="text"
                    value={trailerId}
                    onChange={(e) => setTrailerId(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono font-bold focus:border-cyan-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Carrier Organization</label>
                  <input
                    type="text"
                    value={carrier}
                    onChange={(e) => setCarrier(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Bill of Lading (BOL)</label>
                  <input
                    type="text"
                    value={bolNumber}
                    onChange={(e) => setBolNumber(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 font-mono focus:border-cyan-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Driver Name</label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Trailer Specification</label>
                  <select
                    value={trailerType}
                    onChange={(e) => setTrailerType(e.target.value as 'dry_van_53' | 'reefer_53')}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none font-mono"
                  >
                    <option value="dry_van_53">53ft Dry Van</option>
                    <option value="reefer_53">53ft Refrigerated Reefer</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Cargo Description</label>
                <input
                  type="text"
                  value={cargoDesc}
                  onChange={(e) => setCargoDesc(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-100 focus:border-cyan-400 focus:outline-none"
                />
              </div>

              {/* Seal Inspection Check */}
              <div className="p-3 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-slate-300 font-semibold block">Bolt Seal Verification</span>
                  <span className="text-slate-500 text-[11px] font-mono">Seal: {sealNumber}</span>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sealVerified}
                    onChange={(e) => setSealVerified(e.target.checked)}
                    className="w-4 h-4 rounded text-cyan-500 bg-slate-900 border-slate-700 focus:ring-0"
                  />
                  <span className="text-xs text-emerald-400 font-semibold">Verified Intact</span>
                </label>
              </div>

              {/* Dynamic Yard / Dock Routing Decision */}
              <div className="p-3 bg-cyan-950/20 border border-cyan-800/60 rounded">
                <label className="block text-cyan-300 font-semibold mb-1">
                  Destination Routing Assignment
                </label>
                <p className="text-[11px] text-slate-400 mb-2">
                  System recommends direct-to-dock routing to minimize hostler double-handling.
                </p>

                <select
                  value={assignedDestination}
                  onChange={(e) => setAssignedDestination(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-cyan-700/80 rounded text-cyan-200 font-mono font-bold focus:outline-none text-xs"
                >
                  <optgroup label="Direct to Dock Doors (Fast Unload)">
                    {dockDoors.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.id} · {d.name} ({d.status === 'available' ? 'Available Now' : d.status})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Yard Drop Staging (Zone A)">
                    {yardSpots.filter(s => s.zone === 'Zone A (Inbound)').map(s => (
                      <option key={s.id} value={s.id}>
                        Spot {s.id} ({s.occupiedTrailerId ? 'Occupied' : 'Open'})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Reefer Shore Power (Row R)">
                    {yardSpots.filter(s => s.zone === 'Reefer Row R').map(s => (
                      <option key={s.id} value={s.id}>
                        Reefer Plug {s.id} ({s.occupiedTrailerId ? 'Occupied' : 'Open'})
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                <button
                  onClick={handleAuthorizeCheckIn}
                  className="w-full py-2.5 px-4 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors shadow-md flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Authorize Inbound & Lift Gate Barrier</span>
                </button>
              </div>

            </div>
          </div>
        </div>

      </div>

      {/* Recent Gate Activity Log */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Autonomous Gate Clearance Activity Log
            </h3>
          </div>
          <span className="text-xs text-slate-400">Average lane processing duration: 58 seconds</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-mono">
                <th className="py-2.5 px-3">Time</th>
                <th className="py-2.5 px-3">Trailer ID</th>
                <th className="py-2.5 px-3">Carrier</th>
                <th className="py-2.5 px-3">Driver</th>
                <th className="py-2.5 px-3">Direction</th>
                <th className="py-2.5 px-3">Assigned Location</th>
                <th className="py-2.5 px-3">Processing Duration</th>
                <th className="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-200">
              {gateLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400">{log.timestamp}</td>
                  <td className="py-2.5 px-3 font-bold text-white">{log.trailerId}</td>
                  <td className="py-2.5 px-3 font-sans font-medium">{log.carrier}</td>
                  <td className="py-2.5 px-3 font-sans text-slate-300">{log.driverName}</td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded text-[11px] ${
                      log.action === 'check_in' ? 'bg-cyan-500/10 text-cyan-300' : 'bg-emerald-500/10 text-emerald-300'
                    }`}>
                      {log.action === 'check_in' ? 'INBOUND' : 'OUTBOUND'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-cyan-400">{log.assignedLocation}</td>
                  <td className="py-2.5 px-3 tabular-nums">{log.durationSeconds}s</td>
                  <td className="py-2.5 px-3 text-right">
                    <span className="text-emerald-400 font-semibold font-sans">Cleared</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
