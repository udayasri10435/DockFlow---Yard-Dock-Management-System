/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header, ActiveTab } from './components/layout/Header';
import { YardMapView } from './components/yard/YardMapView';
import { TrailerDetailModal } from './components/yard/TrailerDetailModal';
import { GateKioskView } from './components/gate/GateKioskView';
import { DockScheduleView } from './components/dock/DockScheduleView';
import { HostlerDispatchView } from './components/hostler/HostlerDispatchView';
import { DetentionRadarView } from './components/detention/DetentionRadarView';
import { RoiAnalyticsView } from './components/roi/RoiAnalyticsView';

import { 
  INITIAL_DOCK_DOORS, 
  INITIAL_YARD_SPOTS, 
  INITIAL_TRAILERS, 
  INITIAL_GATE_LANES, 
  INITIAL_GATE_LOGS, 
  INITIAL_HOSTLER_TASKS, 
  INITIAL_APPOINTMENTS 
} from './data/mockYardData';

import { Trailer, DockDoor, YardSpot, GateLane, GateLogEntry, HostlerTask, Appointment } from './types/yard';
import { sounds } from './utils/audio';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('yard_map');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Core application state
  const [trailers, setTrailers] = useState<Trailer[]>(INITIAL_TRAILERS);
  const [dockDoors, setDockDoors] = useState<DockDoor[]>(INITIAL_DOCK_DOORS);
  const [yardSpots, setYardSpots] = useState<YardSpot[]>(INITIAL_YARD_SPOTS);
  const [gateLanes, setGateLanes] = useState<GateLane[]>(INITIAL_GATE_LANES);
  const [gateLogs, setGateLogs] = useState<GateLogEntry[]>(INITIAL_GATE_LOGS);
  const [hostlerTasks, setHostlerTasks] = useState<HostlerTask[]>(INITIAL_HOSTLER_TASKS);
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS);

  // Modals & drawers
  const [selectedTrailer, setSelectedTrailer] = useState<Trailer | null>(null);

  // Real-time ticking simulation: advance trailer dwell minutes every 45 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setTrailers(prevTrailers => 
        prevTrailers.map(t => {
          if (t.status === 'departed') return t;
          return {
            ...t,
            dwellMinutes: t.dwellMinutes + 1
          };
        })
      );
    }, 45000);

    return () => clearInterval(timer);
  }, []);

  // Compute detention alert count for Header badge
  const detentionAlertCount = trailers.filter(t => (t.freeTimeLimitMinutes - t.dwellMinutes) <= 30).length;

  // Move a trailer between spots or dock doors
  const handleDispatchMove = (trailerId: string, toLocation: string, reason: string) => {
    const trailer = trailers.find(t => t.id === trailerId);
    if (!trailer) return;

    const fromLocation = trailer.locationId;
    const isTargetDock = toLocation.startsWith('D-');

    // 1. Create a hostler task
    const newTask: HostlerTask = {
      id: `TSK-${Math.floor(420 + Math.random() * 500)}`,
      trailerId,
      carrier: trailer.carrier,
      taskType: isTargetDock ? 'spot_to_dock' : 'dock_to_spot',
      fromLocation,
      toLocation,
      priority: (trailer.freeTimeLimitMinutes - trailer.dwellMinutes) <= 30 ? 'urgent' : 'normal',
      status: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      reason,
      detentionSavings: 170
    };

    setHostlerTasks(prev => [newTask, ...prev]);

    // 2. Relocate trailer in state
    setTrailers(prev => prev.map(t => {
      if (t.id !== trailerId) return t;
      return {
        ...t,
        locationId: toLocation,
        locationType: isTargetDock ? 'dock_door' : 'yard_spot',
        status: isTargetDock ? 'docked' : 'yard_staged'
      };
    }));

    // 3. Update previous spot/dock and target spot/dock
    if (fromLocation.startsWith('D-')) {
      setDockDoors(prev => prev.map(d => {
        if (d.id === fromLocation) {
          return { ...d, status: 'available', currentTrailerId: undefined, operation: 'idle', progressPercent: 0 };
        }
        return d;
      }));
    } else {
      setYardSpots(prev => prev.map(s => {
        if (s.id === fromLocation) {
          return { ...s, occupiedTrailerId: undefined };
        }
        return s;
      }));
    }

    if (toLocation.startsWith('D-')) {
      setDockDoors(prev => prev.map(d => {
        if (d.id === toLocation) {
          return { ...d, status: 'staged', currentTrailerId: trailerId, operation: 'unloading', progressPercent: 10 };
        }
        return d;
      }));
    } else {
      setYardSpots(prev => prev.map(s => {
        if (s.id === toLocation) {
          return { ...s, occupiedTrailerId: trailerId };
        }
        return s;
      }));
    }
  };

  // Departure from gate
  const handleDepartTrailer = (trailerId: string) => {
    const trailer = trailers.find(t => t.id === trailerId);
    if (!trailer) return;

    // Free location
    const loc = trailer.locationId;
    if (loc.startsWith('D-')) {
      setDockDoors(prev => prev.map(d => d.id === loc ? { ...d, status: 'available', currentTrailerId: undefined } : d));
    } else {
      setYardSpots(prev => prev.map(s => s.id === loc ? { ...s, occupiedTrailerId: undefined } : s));
    }

    // Update trailer status
    setTrailers(prev => prev.filter(t => t.id !== trailerId));

    // Log outbound
    const newLog: GateLogEntry = {
      id: `GL-${Math.floor(9040 + Math.random() * 500)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      trailerId,
      carrier: trailer.carrier,
      driverName: trailer.driverName || 'Carrier Driver',
      action: 'check_out',
      assignedLocation: `Departed via Gate 3`,
      durationSeconds: 44,
      bolNumber: trailer.bolNumber,
      status: 'cleared'
    };

    setGateLogs(prev => [newLog, ...prev]);
  };

  // Gate check-in
  const handleCheckInTrailer = (newTrailer: Trailer, assignedSpotOrDock: string, logEntry: GateLogEntry) => {
    setTrailers(prev => [newTrailer, ...prev]);
    setGateLogs(prev => [logEntry, ...prev]);

    if (assignedSpotOrDock.startsWith('D-')) {
      setDockDoors(prev => prev.map(d => {
        if (d.id === assignedSpotOrDock) {
          return {
            ...d,
            status: 'staged',
            currentTrailerId: newTrailer.id,
            operation: 'unloading',
            progressPercent: 5,
            estimatedRemainingMinutes: 60
          };
        }
        return d;
      }));
    } else {
      setYardSpots(prev => prev.map(s => {
        if (s.id === assignedSpotOrDock) {
          return {
            ...s,
            occupiedTrailerId: newTrailer.id
          };
        }
        return s;
      }));
    }
  };

  // Update dock status
  const handleUpdateDock = (updatedDoor: DockDoor) => {
    setDockDoors(prev => prev.map(d => d.id === updatedDoor.id ? updatedDoor : d));
  };

  // Schedule appointment
  const handleScheduleAppointment = (newAppt: Appointment) => {
    setAppointments(prev => [newAppt, ...prev]);
  };

  // Request hostler pull from dock
  const handleRequestHostlerPull = (dockId: string, currentTrailerId: string) => {
    const trailer = trailers.find(t => t.id === currentTrailerId);
    const targetSpot = yardSpots.find(s => !s.occupiedTrailerId && s.zone === 'Zone B (Outbound)');
    const destination = targetSpot ? targetSpot.id : 'B-02';

    const newTask: HostlerTask = {
      id: `TSK-${Math.floor(430 + Math.random() * 500)}`,
      trailerId: currentTrailerId,
      carrier: trailer ? trailer.carrier : 'Carrier Freight',
      taskType: 'dock_to_spot',
      fromLocation: dockId,
      toLocation: destination,
      priority: 'urgent',
      status: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      reason: `Pull completed trailer from ${dockId} to free dock bay`,
      detentionSavings: 90
    };

    setHostlerTasks(prev => [newTask, ...prev]);

    // Update trailer to outbound_ready at new spot
    setTrailers(prev => prev.map(t => {
      if (t.id === currentTrailerId) {
        return {
          ...t,
          status: 'outbound_ready',
          locationId: destination,
          locationType: 'yard_spot'
        };
      }
      return t;
    }));

    if (targetSpot) {
      setYardSpots(prev => prev.map(s => s.id === destination ? { ...s, occupiedTrailerId: currentTrailerId } : s));
    }
  };

  // Update hostler task status
  const handleUpdateTaskStatus = (taskId: string, newStatus: 'assigned' | 'hooked' | 'completed') => {
    setHostlerTasks(prev => prev.map(t => {
      if (t.id !== taskId) return t;
      return {
        ...t,
        status: newStatus,
        assignedHostler: t.assignedHostler || 'Jockey-01 (Mac / Ottawa T2)'
      };
    }));

    // If completed, ensure trailer location matches
    if (newStatus === 'completed') {
      const task = hostlerTasks.find(t => t.id === taskId);
      if (task) {
        setTrailers(prev => prev.map(tr => {
          if (tr.id === task.trailerId) {
            return {
              ...tr,
              locationId: task.toLocation,
              locationType: task.toLocation.startsWith('D-') ? 'dock_door' : 'yard_spot'
            };
          }
          return tr;
        }));
      }
    }
  };

  // 1-Click Expedite move from Detention Radar
  const handleExpediteMove = (trailer: Trailer) => {
    const openDock = dockDoors.find(d => d.status === 'available');
    const destination = openDock ? openDock.id : 'D-03';
    handleDispatchMove(trailer.id, destination, 'Emergency Detention Mitigation');
    sounds.playRadioChirp();
    setActiveTab('hostler_queue');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* 3-Zone Top Navigation Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        detentionAlertCount={detentionAlertCount}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        onOpenQuickCheckIn={() => setActiveTab('gate_kiosk')}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'yard_map' && (
          <YardMapView
            trailers={trailers}
            dockDoors={dockDoors}
            yardSpots={yardSpots}
            onSelectTrailer={(t) => setSelectedTrailer(t)}
            onSelectDock={(d) => {
              setActiveTab('dock_schedule');
            }}
            onNavigateTab={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === 'gate_kiosk' && (
          <GateKioskView
            gateLanes={gateLanes}
            gateLogs={gateLogs}
            trailers={trailers}
            dockDoors={dockDoors}
            yardSpots={yardSpots}
            onCheckInTrailer={handleCheckInTrailer}
            onDepartTrailer={handleDepartTrailer}
          />
        )}

        {activeTab === 'dock_schedule' && (
          <DockScheduleView
            dockDoors={dockDoors}
            trailers={trailers}
            appointments={appointments}
            onUpdateDock={handleUpdateDock}
            onScheduleAppointment={handleScheduleAppointment}
            onRequestHostlerPull={handleRequestHostlerPull}
          />
        )}

        {activeTab === 'hostler_queue' && (
          <HostlerDispatchView
            tasks={hostlerTasks}
            trailers={trailers}
            dockDoors={dockDoors}
            yardSpots={yardSpots}
            onUpdateTaskStatus={handleUpdateTaskStatus}
            onCreateTask={(newTask) => setHostlerTasks(prev => [newTask, ...prev])}
          />
        )}

        {activeTab === 'detention_radar' && (
          <DetentionRadarView
            trailers={trailers}
            dockDoors={dockDoors}
            onExpediteMove={handleExpediteMove}
            onSelectTrailer={(t) => setSelectedTrailer(t)}
          />
        )}

        {activeTab === 'roi_analytics' && (
          <RoiAnalyticsView
            trailers={trailers}
            dockDoors={dockDoors}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>DockFlow YMS · Enterprise Yard & Dock Management System</span>
          <span className="font-mono text-slate-600">Distribution Center Logistics OS · High-ROI Operations</span>
        </div>
      </footer>

      {/* Trailer Detail Drawer Modal */}
      {selectedTrailer && (
        <TrailerDetailModal
          trailer={selectedTrailer}
          dockDoors={dockDoors}
          yardSpots={yardSpots}
          onClose={() => setSelectedTrailer(null)}
          onDispatchMove={handleDispatchMove}
          onDepartTrailer={handleDepartTrailer}
        />
      )}
    </div>
  );
}
