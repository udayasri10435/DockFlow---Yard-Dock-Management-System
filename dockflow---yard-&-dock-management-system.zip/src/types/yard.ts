export type TrailerType = 'dry_van_53' | 'reefer_53' | 'flatbed' | 'container_chassis';

export type TrailerStatus = 
  | 'in_gate_staging' 
  | 'docked' 
  | 'yard_staged' 
  | 'unloading' 
  | 'loading' 
  | 'empty_staged' 
  | 'outbound_ready' 
  | 'departed';

export type SpotZone = 'Zone A (Inbound)' | 'Zone B (Outbound)' | 'Reefer Row R' | 'Empties E';

export interface ReeferTelemetry {
  currentTempF: number;
  setPointF: number;
  fuelLevelPercent: number;
  mode: 'continuous' | 'start_stop';
  status: 'running' | 'cycling' | 'standby' | 'alarm';
  alarmCode?: string;
  pluggedIn: boolean;
}

export interface Trailer {
  id: string;
  carrier: string;
  trailerType: TrailerType;
  status: TrailerStatus;
  locationType: 'dock_door' | 'yard_spot' | 'gate' | 'in_transit';
  locationId: string; // e.g. "D-04", "A-07", "R-02", "E-03"
  cargoDescription: string;
  weightLbs: number;
  palletsCount: number;
  sealNumber: string;
  isSealed: boolean;
  checkInTime: string; // ISO or timestamp
  dwellMinutes: number;
  freeTimeLimitMinutes: number; // typically 120
  detentionRatePerHour: number; // typically $85/hr
  bolNumber: string;
  driverName: string;
  driverPhone: string;
  tractorPlate: string;
  reefer?: ReeferTelemetry;
  assignedHostler?: string;
  priority: 'critical' | 'high' | 'normal' | 'low';
}

export interface DockDoor {
  id: string; // D-01 to D-16
  name: string;
  type: 'dry' | 'cold_storage' | 'cross_dock';
  status: 'available' | 'docked_active' | 'staged' | 'reserved' | 'maintenance';
  currentTrailerId?: string;
  operation: 'unloading' | 'loading' | 'idle';
  progressPercent: number;
  estimatedRemainingMinutes: number;
  assignedCrew: string;
  appointmentId?: string;
}

export interface YardSpot {
  id: string; // A-01, B-01, R-01, E-01...
  zone: SpotZone;
  type: 'standard' | 'reefer_plug' | 'staging' | 'empty';
  occupiedTrailerId?: string;
  hasPowerPlug: boolean;
}

export interface GateLane {
  id: string;
  name: string;
  type: 'inbound' | 'outbound';
  status: 'idle' | 'processing' | 'cleared' | 'flagged';
  barrierArm: 'closed' | 'open' | 'opening' | 'closing';
  activeScan?: {
    tractorPlate: string;
    trailerId: string;
    carrier: string;
    driverName: string;
    bolNumber: string;
    sealNumber: string;
    weightLbs: number;
    destinationRecommendation: string;
    confidence: number;
    matchFound: boolean;
  };
}

export interface GateLogEntry {
  id: string;
  timestamp: string;
  trailerId: string;
  carrier: string;
  driverName: string;
  action: 'check_in' | 'check_out';
  assignedLocation: string;
  durationSeconds: number;
  bolNumber: string;
  status: 'cleared' | 'flagged' | 'manual_review';
}

export interface HostlerTask {
  id: string;
  trailerId: string;
  carrier: string;
  taskType: 'gate_to_spot' | 'spot_to_dock' | 'dock_to_spot' | 'spot_to_gate' | 'reefer_fuel_plug';
  fromLocation: string;
  toLocation: string;
  priority: 'urgent' | 'high' | 'normal';
  status: 'pending' | 'assigned' | 'hooked' | 'completed';
  assignedHostler?: string;
  createdAt: string;
  reason: string;
  detentionSavings: number;
}

export interface Appointment {
  id: string;
  carrier: string;
  trailerId?: string;
  type: 'inbound_unload' | 'outbound_load' | 'drop_and_hook';
  scheduledTime: string; // e.g. "08:30 AM"
  status: 'scheduled' | 'checked_in' | 'at_dock' | 'completed' | 'delayed';
  dockDoorId: string;
  cargoType: string;
  pallets: number;
  poNumber: string;
}
